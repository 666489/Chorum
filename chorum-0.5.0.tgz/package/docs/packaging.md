# 打包与"统一 Agent 接口"

> 当前交付为本地 `.tgz`，尚未发布到 npm 公共仓库。使用 `npm i -g "./claudelink-hub-0.4.0.tgz"` 安装。
> 便携化目标：不依赖作者本机的 Node/Python 路径，
> 安装时自动识别已装的 AI Agent CLI，加新 Agent 不用改代码。
>
> 对应 2026-10-25 的便携化改造（含一次安全审计的修复）。

---

## 1. 三条硬规则（改代码前先读）

1. **代码里不允许出现机器专属绝对路径**（作者把 Node.js / Python 装在非默认盘、或把自己的用户名写进路径）。
   位置只能用三种形式表达：
   - 环境变量占位符：`%APPDATA%/npm`、`%LOCALAPPDATA%/Programs`
   - `~`（跨平台都能展开）：`~/.local/bin`、`~/.cargo/bin`
   - PATH 里的**裸命令名**：`claude`、`codex`
   - 运行时推导：`npm prefix -g`、`~/.conda/environments.txt`
2. **随包发布的只有模板与代码**；`config.json`、`hub.db*`、`*.log`、`uploads/`、检测缓存
   都是**生成物**，不进版本库、不进 npm 包（`.gitignore` + `files` 白名单双重保障）。
3. **Windows 上 `npm`/`.cmd` 不能被直接 spawn**（会 ENOENT），一律经 `cmd /d /s /c`；
   含空格的 `.cmd` 路径还要先转 8.3 短路径，否则 cmd 解析会崩（`hub.py: wrap_command`）。

---

## 2. 路径解析：四层优先级 + 九层自动发现

| 层 | 来源 | 谁写 | 说明 |
|---|---|---|---|
| 1 | 环境变量 `CLAUDELINK_<ID>`（如 `CLAUDELINK_CODEX`） | 用户 | **最高优先级**，临时换 CLI 用 |
| 2 | `config.json` 的 `agents.<id>.exe` | `setup` 或用户手改 | 允许 `%VAR%`；**失效路径会被跳过**（CLI 升级后自动往下找） |
| 3 | **检测缓存** `~/.claudelink/agents.detected.json` | `postinstall` / `detect --write` / `start` / `doctor` | 安装时自动识别的本机真实路径 |
| 4 | 裸名 → PATH → `candidate_bin_dirs()` | 运行时 | PATH、`npm prefix -g`、`%APPDATA%\npm`、`~/.local/bin`、`~/.bun/bin`、`~/.volta/bin`、`~/.cargo/bin`、`%LOCALAPPDATA%\OpenAI\Codex\bin\*` 等 |

**取值顺序**在 JS（detect）与 Python（hub.py）两侧一致：env → config → 检测缓存 → PATH/常见目录。
差异只有一处：**JS 只写缓存、不读**；**Python 会读** `agents.detected.json`。

> `candidate_bin_dirs()` 里的通配（如 `%LOCALAPPDATA%\OpenAI\Codex\bin\*`）会**按修改时间取最新**，
> 用来适配 Codex 桌面版那种"版本号哈希目录"的布局。

### 两个**不同**的 JSON（别混）

| 文件 | 用途 | 谁写 |
|---|---|---|
| `~/.claudelink/agents.json` | **用户自定义 Agent 注册表**（数组或 `{agents:[...]}`） | **只有用户**（工具永不写） |
| `~/.claudelink/agents.detected.json` | 检测缓存（`{schema,byId}`） | 工具自动写 |

两者分开是为了避免"写缓存把用户手写的条目整份覆盖"（审计出来的 Critical 数据丢失问题）。
旧版本的缓存如果落在 `agents.json`，`detect --write` 会**自动迁移**到新文件（只在目标是用户数组时不搬）。

### 2.1 检测层：`bin/detect.js` 的九层（前面的命中优先）

| # | 层（`source`） | 来源 | 默认 | 备注 |
|---|---|---|---|---|
| 1 | `env` | 环境变量 `CLAUDELINK_<ID>` | 用户设置才生效 | 最高优先级 |
| 2 | `config` | `config.agents.<id>.exe`（允许 `%VAR%`） | `setup` 写入 | 失效路径自动跳过 |
| 3 | `path` | PATH 里的裸命令名（自动补 `.exe/.cmd/.bat`） | 总是 | |
| 4 | `known-dir` | 注册表 `paths`（`%VAR%` / `~` / `*` 通配） | 总是 | 声明成 `xxx.cmd` 时只试该文件本身 |
| 5 | `npm-root` | `npm prefix -g` 推出的全局根 | 总是 | 可用 `CLAUDELINK_NPM_PREFIX` 覆盖 |
| 6 | `search-root` | 通用搜索根（`~/.local/bin`、`%LOCALAPPDATA%\Programs`…） | 总是 | 用户自己的目录优先于系统 |
| 7 | `extra-root` | `detect.extra_roots`（用户声明的额外目录） | **空 = 关闭** | 只浅扫一层；跳过系统目录根与网络盘 |
| 8 | `scan-dir` | 注册表 `scanDirs`（含版本哈希子目录，深 2 层） | 总是 | Codex 桌面版那种布局靠它 |
| 9 | `everything` | Everything 的 `es.exe`（可选加速层，仅 Windows） | 见 §2.2 | 默认不扫全盘 |

**第 7、9 层是新增的「可选层」**：默认配置下零行为变化；关掉它们，1–6、8 的优先级与语义
与便携化改造时（2026-10-25）完全一致。

> 逐层排障：`claudelink-hub detect --explain <id>` 会按上表逐层打印「试过的具体位置 →
> 命中/不存在/不可用(原因)」，最后给一句结论 + 一条可复制的补法（`setx` / `export`，
> 或把目录加进 `detect.extra_roots`）。`doctor --json` 的 `detected.missing[]` 是同一份
> 材料的机器可读版（每个未找到的 Agent 都带 `id/label/layers/suggestion`）。

### 2.2 可选加速层：Everything（`es.exe`）

```json
"detect": {
  "extra_roots": [],
  "everything": {
    "enabled": "auto",
    "exe": "",
    "roots": [],
    "allow_full_scan": false,
    "timeout_ms": 3000,
    "max_results": 50
  }
}
```

- **es.exe 定位顺序**：`CLAUDELINK_ES` → `detect.everything.exe` → 常见安装目录
  （`%ProgramFiles%\Everything`、`%ProgramFiles(x86)%\Everything`、`%LOCALAPPDATA%\Programs\Everything`）
  → PATH 里的 `es`。
- **查询方式**：一次调用把所有注册表命令名合并成一条**精确文件名正则**
  （如 `^(claude|codex|codebuddy)(\.(exe|cmd|bat))?$`），每个搜索根一次 `-path`；
  不用模糊匹配，避免把 `claude-helper.exe` 这类同名变体当成 Agent。
- **默认不扫全盘**：`roots` 为空且 `allow_full_scan` 不为 `true` 时，这一层**不做任何查询**
  （状态 `no-roots`）。要全盘必须显式写 `"allow_full_scan": true`。
- **护栏**：`timeout_ms` 是**整体预算**（默认 3000ms，多根不会乘出 N 倍）、
  `max_results`（默认 50）、只接受**普通文件**、只保留注册表声明过的命令名、结果去重、
  `source` 标 `everything`；输出按 UTF-8 解码，失败退 cp936。
- **失败语义**：es.exe 不存在 / 超时 / 非零退出 → **静默回退**原链路，不打印、不影响退出码、
  不写 `hub.log`；只在 `detect --explain` 的第 9 层与 `doctor` 的 `Everything` 行里说明原因。
- **隐私**：查询结果只进内存 → 按既有规则写 `agents.detected.json`，不落任何其它文件。
- `enabled`：`false` 整体关闭（连 es.exe 都不找）；`"auto"`（默认）与 `true` 等价 ——
  **找到 es.exe 才生效**，且仍受 `roots`/`allow_full_scan` 约束（布尔写法只是给手写配置留的兼容形态）。

`detect.extra_roots`（第 7 层）同理：默认空、只浅扫一层、跳过文件系统根 / 系统目录根 / UNC 网络盘。
映射到盘符的网络盘在纯 Node 里无法判别，**建议写 UNC 路径或干脆不用**。

### 2.3 三级保证（`doctor` 会打印同一句）

| 级别 | 覆盖 | 说明 |
|---|---|---|
| **保证** | PATH / npm 全局 / 已知目录 / 用户声明（`env`、`config`、`extra_roots`） | 常规安装一定能找到 |
| **尽力** | Everything、`extra_roots`、版本哈希扫描（`scan-dir`） | 依赖本机条件，找不到不报错 |
| **不保证** | 绿色版装在任意盘且不在 PATH、注册表里没有的新 Agent、`sudo` 安装导致 `HOME` 错位 | 用 `detect --explain` 看原因并手动补 |

---

## 3. 安装与使用

```bash
npm i -g "./claudelink-hub-0.4.0.tgz"  # 先进入安装包所在目录；postinstall 自动识别本机 CLI
claudelink-hub doctor       # 体检：Agent / Python / npm 前缀 / 数据目录 / 缓存（--json 机器可读）
claudelink-hub start        # 检测 → 装配 config.json → 启动并打开 Web UI
claudelink-hub detect --json    # 机器可读的检测结果（带 source：env/config/path/scan-dir…）
claudelink-hub setup --dry-run  # 只看会改什么
claudelink-hub stop             # 让中枢退出（server.allow_shutdown=true 时）
```

> 上面这些 `claudelink-hub …` 是**全局安装后**才有的命令；没装全局时用 `node bin/cli.js …` 等价调用。

**前置依赖**：Node ≥ 18；Python ≥ 3.9（中枢只用标准库，含 `sqlite3`）。
Python 查找顺序：`CLAUDELINK_PYTHON` → `CONDA_PREFIX` → `py -3` → `python3`/`python`（PATH）
→ **`~/.conda/environments.txt` 里登记的每个环境** → 各平台的常见安装目录。
（Windows 应用商店那个 `python.exe` 存根会被探针自动淘汰。）

**环境变量**

| 变量 | 作用 |
|---|---|
| `CLAUDELINK_CONFIG` | 配置文件路径（默认 `<数据目录>/config.json`） |
| `CLAUDELINK_HOME` | **数据目录**（config / hub.db / 日志 / 上传 / PID）；默认包目录 |
| `CLAUDELINK_PYTHON` | 指定 Python 解释器 |
| `CLAUDELINK_AGENTS` | 检测缓存路径（默认 `~/.claudelink/agents.detected.json`） |
| `CLAUDELINK_ES` | Everything 的 `es.exe` 路径（可选加速层，仅 Windows；不设则按 §2.2 顺序找） |
| `CLAUDELINK_USER_AGENTS` | 用户注册表路径（默认 `~/.claudelink/agents.json`） |
| `CLAUDELINK_REGISTRY` | 指向一个导出 `{AGENTS}` 的 JS 文件，**合并**并按 id 覆盖内置；相对路径须 `./` 开头 |
| `CLAUDELINK_NODE` | codebuddy / dsh 用的 node 解释器 |
| `CLAUDELINK_CLAUDE_SETTINGS_DIR` | claude 的 ccm profile 目录（默认 `~/.ccm/settings`） |
| `CLAUDELINK_NPM_PREFIX` | 覆盖 `npm prefix -g` 的结果 |
| `CLAUDELINK_<ID>` | 覆盖某个 Agent 的入口（如 `CLAUDELINK_CODEX=C:\…\codex.exe`） |

### 数据目录（只读安装也能跑）

- 包目录**可写**（本地 clone / 开发）→ 数据仍写在包目录（向后兼容）。
- 系统级全局安装（如 `/usr/lib/node_modules`，root 所有）→ 自动落到 `~/.claudelink-hub`，
  否则首次 `start` 会 EACCES、`hub.db` 建不出来。
- `doctor` 会打印「数据目录」以及它是否已切换。

---

## 4. 加一个新的 AI Agent（不用改 hub.py）

### 4.1 只想"被识别"（detect）

编辑 `bin/registry.js` 的 `AGENTS` 数组，**或**在 `~/.claudelink/agents.json` 里加一条（推荐，升级不丢）：

```json
[
  {
    "id": "myagent",
    "label": "My Agent",
    "bin": ["myagent", "myagent.cmd"],
    "env": "CLAUDELINK_MYAGENT",
    "versionArgs": ["--version"],
    "support": "detect",
    "paths": ["%APPDATA%/npm/myagent.cmd", "~/.local/bin/myagent"],
    "defaults": { "label": "My Agent", "stream": true, "relay": true },
    "note": "先只识别；参数实测后再切成 generic"
  }
]
```

跑 `claudelink-hub doctor`，能看到它出现在表里、并标出**来源**（env / config / path / known-dir /
npm-root / search-root / scan-dir）。

### 4.2 想让它"能跑"（generic）

把 `support` 改成 `generic`，加上 `generic` 声明（模板定义见 `bin/registry.js` 顶部 `GENERIC_TEMPLATE`）：

```json
{
  "id": "myagent",
  "label": "My Agent",
  "bin": ["myagent"],
  "env": "CLAUDELINK_MYAGENT",
  "support": "generic",
  "generic": {
    "promptVia": "arg",
    "promptFlag": ["-p"],
    "modelFlag": "--model",
    "sessionArgs": ["--session-id", "{session}"],
    "streamArgs": ["--output-format", "stream-json"],
    "jsonLines": true,
    "text_field": "result",
    "session_field": "session_id"
  },
  "defaults": { "label": "My Agent", "stream": true, "relay": true }
}
```

`setup` 会把它**翻译**成 hub.py `run_generic_cli()` 认的 schema 再写进 `config.json`：

| 模板字段 | → hub 字段 | 说明 |
|---|---|---|
| `promptVia: arg` + `promptFlag` | `args: [...flag, "{prompt}"]` | 常见形态 |
| `promptVia: stdin` / `env` | `stdin: true` | hub 通用 runner 没有 env 传 prompt，用 stdin 等价表达 |
| `streamArgs` | 前置拼进 `args` | 如 `["--output-format","stream-json"]` |
| `modelFlag` | `model_args: [flag, "{model}"]` | 仅当 `agents.<id>.model` 非空才传 |
| `sessionArgs` | `create_args` + `resume_args` | 用 `resumeArgs` 可单独覆盖"续接"那套 |
| `jsonLines` | `output: "jsonl"` | 逐行 JSON 输出 |
| `text_field` / `list_field` / `session_field` | 原样透传 | 从 JSON 行里取正文/会话 id |

> `supports_native_memory` 会按"是否有 `create_args`/`resume_args`/`session_field`"自动置位。

### 4.3 加 Agent 时的三个坑

1. **别把官方 provider 和第三方模型名混用**：给 Codex 传 `model=deepseek-flash` 而 provider 仍是官方
   openai → 必然 400 `model_not_found`（本项目 2026-10-24 的真实故障）。要么 model 留空，要么同时给 provider。
2. **`bin` 要写够变体**（Windows 的 `.exe/.cmd/.bat` 由代码自动补，但命令名本身可能有两个）。
3. **node 入口**（`.js` / 无扩展名的 npm 全局包）要把 `node: true` 打开，运行时会用 PATH 里的 node。

### 4.4 `exe_auto`：自动识别 vs 用户钉死

`setup` 写进 config 的 `exe` 会带 `"exe_auto": true`，表示"这是检测出来的"——
CLI 升级换了目录（Codex 的版本哈希目录最典型）时，下次 `start` 会自动跟随。
如果你手写 `exe`（没有 `exe_auto` 字段）且文件存在，则**永远保留你的值**，不会被覆盖。
**占位符形态**（`%CLAUDELINK_X%`、`~/.local/bin/x`）同样视为"用户意图"，原样保留、不会被改写成绝对路径。

---

## 5. 发布前自检

```bash
npm run check          # 扫描将发布的文件：密钥形态 + 作者隐私；命中即非 0 退出
npm pack --dry-run     # 确认包内没有 config.json / hub.db / agents*.json / *.log / uploads
node bin/cli.js doctor # 本机应能列出 ≥2 个可用 Agent
```

`check-secrets` 的两段逻辑：
- **硬拦截**：只扫 `files` 白名单（= 用户真正下载到的内容），命中密钥/用户目录绝对路径/非默认盘安装路径/
  邮箱就中止发布；私有项目名可写进仓库根的 `.leak-denylist`（已 gitignore）。
- **软提醒**：目录里存在 `hub.db` / `uploads/` / `config.json` 等现场文件时只提示"别 git add / 别整目录外发"。

包内容（`files`）：`bin/` 的 7 个 JS（含 `everything.js`）、`hub.py`、`hub_pid.py`、`hub_tui.py`、`extract.py`、
`web/index.html`、`docs/packaging.md`、`docs/agent-integration.md`、`README.md`、`config.example.json`。
**不含**：`config.json`、`hub.db*`、`*.log`、`uploads/`、`.verify/`、`backup/`、`__pycache__/`、
`scripts/check-secrets.js`（发布守门工具只留在仓库里）。

---

## 6. 目录职责

| 文件 | 职责 |
|---|---|
| `bin/cli.js` | 命令入口：detect / doctor / setup / start / ui / stop；数据目录判定 |
| `bin/registry.js` | **声明式 Agent 注册表**（加 Agent 主要改这里；也支持用户 JSON 覆盖） |
| `bin/detect.js` | 把声明变成"本机真实路径"（九层 + trace），写检测缓存、迁移旧缓存 |
| `bin/everything.js` | Everything `es.exe` 可选加速层：定位 es、精确查询、护栏、静默回退 |
| `bin/setup.js` | 装配 `config.json`（含 generic 模板翻译、`exe_auto`、保留 order） |
| `bin/util.js` | 跨平台工具：占位符展开、PATH/搜索根、npm 前缀、Python 查找、检测缓存路径 |
| `bin/postinstall.js` | 安装时自动识别（尽力而为，永不阻断安装） |
| `scripts/check-secrets.js` | 发布守门（不随包发布） |
| `hub.py` | 中枢本体（Python，仅标准库）：HTTP/Web、成员调度、各 Agent runner |
| `hub_tui.py` | 终端版 UI（与 CLI 共用同一份 config / 数据目录） |
| `extract.py` | 附件解析器（PDF/DOCX 有库用库、没有退回 stdlib） |
| `config.example.json` | 便携配置模板（**唯一随包发布的配置**） |
