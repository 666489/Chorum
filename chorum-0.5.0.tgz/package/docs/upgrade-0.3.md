# 0.3：多智能体讨论与一次调度持续执行

## 0.3.1 启动鉴权修复

修复 npm 版 TUI 与已运行源码实例的数据目录不同导致的 HTTP 401。先验证受保护的接口，再进入状态加载；本机实例登记只保存进程和路径信息，不保存 token。兼容未登记的旧实例时，按目标监听端口定位 `hub.py` 的实际目录，并在鉴权通过后使用其配置、token 与圆桌保存目录。不会复制 token 到其他目录，也不会关闭鉴权或另开一个服务绕过错误。

每次请求重新读取 token 文件，文件更新时不再沿用缓存；请求被 401 拒绝且文件已变化时只重试一次。显式设置的 `CLAUDELINK_TOKEN` 不会被自动替换。`--check` 现在包含鉴权验证；无法鉴权时返回非零退出码和明确错误，不再只凭公开 health 返回 200 报成功。可用 `CLAUDELINK_AUTO_DISCOVER=0` 关闭本机实例自动发现。

补充 10 项真实 HTTP 回归，覆盖目录错配、旧实例、token 更新、首次启动、完整首帧加载与失败提示；并将安装目录下的 `tui --render-once --no-start` 纳入冒烟。

本次修改位于 `claudelink-hub`。根目录的 PEACOCK 页面仍是上下文配置工具。启动中枢用 `node bin/cli.js start`；终端用 `claudelink-hub tui`、`npm run tui` 或同一解释器运行 `hub_tui.py`。Node 18+、Python 3.9+，没有新增第三方运行依赖。

## 实际修复

- Windows `wrap_command` 原来会把任意 `.cmd` 替换成同目录的 Claude.exe，包括 Codex。现在按命令名匹配；npm 版 Codex 直接用 Node 启动其 JS 入口，避免 cmd.exe 二次转义 JSON 配置。
- Codex 默认使用已安装 CLI 的 `exec --json`，原生记忆使用 `exec resume`，复用 CLI 本机登录、模型与 provider 配置。提示词通过 stdin 传入，解析真实工具、推理摘要、结束与 usage 事件。只有成功结束且返回最终文本才算成功；失败不自动重复执行工具。旧 app-server 可显式设置 `agents.codex.transport="app-server"`，此次真实连接验收针对 exec。
- 修复 POST 路由被 MCP 方法定义切断而不可达的问题，恢复停止、模型设置、权限、重试等接口；未知路径返回 404。
- 修复收件箱持有数据库锁时再次读取 active_conv 造成的死锁；修复预算拒绝、取消与停止未释放同步等待者的问题；失败的成员调用不再标为队列已完成。
- 子进程输入与输出并发处理。大提示词不再堵在 stdin 写入上，使取消和超时无法生效。

## 两种协作

### 圆桌讨论

保留 `/round`、`/round again`、固定角色、重复实例和发言顺序。每个回合都带原始议题，第一句要求给出自己的实质结论，再逐项回应原始问题、比较已有意见。上一位的意见只作为材料，不再作为默认主线；明确禁止把对象换成文档评价或流程设计，除非原议题要求。

这是一项提示约束和上下文修复，不是语义正确性的自动证明。用户给出的思想讨论样例尚未做真实三成员、多轮盲测，不能声称已消除话题漂移。

### 主代理只调度一次，执行代理持续工作

```text
/work start 1 原始任务与验收条件
/work status
/work stop <任务id>
/work resume <任务id>
```

主代理可用编号或成员 id。当前选中成员作为执行代理，未选中则使用所有启用成员；同一 CLI 也可以承担主代理和执行代理。主代理只输出一次 JSON 计划。任务有独立 id、执行成员、依赖与指令；计划按拓扑顺序验证，拒绝循环和未知成员。

执行代理按 `done / continue / blocked` 返回检查点。`continue` 自动续跑，默认每个子任务最多 4 步；API `max_steps` 可设 1–20。依赖完成后才运行后继任务，同一成员串行、不同成员服从现有队列并发和预算。主代理不会为每个步骤重新调度，也不会额外调用一次总结模型。

计划和检查点写入现有 SQLite 状态。重启把运行中工作转为暂停，恢复时跳过已完成任务。计划尚未保存就中断时，恢复会明确拒绝隐式再次调度。工作流的完成来自执行代理报告；它不是独立验收器，`summary` 的事实性仍需按任务的实际产物核查。失败、阻塞与步数耗尽不会算完成。

## 终端

| 命令 | 行为 |
| --- | --- |
| `/model` | 查看当前模型 |
| `/model 1` | 查看该 CLI 的模型目录，可自由填模型 id |
| `/model 1 <model> [provider]` | 切换该成员模型并清除原生会话 |
| `/effort 1` | 查看适配层可传的 effort |
| `/effort 1 low` | 设置推理强度；`auto` 跟随服务商默认 |
| `/tools` | 工具参数、结果、错误的可滚动记录 |
| `/view thinking` | 已保存与进行中的完整可见推理摘要，滚轮回看 |
| `/view messages` | 返回讨论 |
| `/work status` | 任务、执行者、检查点和阻塞状态 |

界面增加讨论、工具、推理、任务入口，Ctrl+O 切换视图，成员栏显示模型和 effort；继续使用 SSE，不加入自动轮询。上翻时新流式内容保持阅读位置。只展示服务商实际输出的推理内容，不伪造或恢复隐藏思维链。CLI JSONL 的正文粒度依 CLI 版本，exec 常在单条消息完成时才返回正文，不保证逐 token 输出。

effort 是协议参数而不是所有模型通用的能力承诺。Codex、Claude 与 OpenAI/Anthropic API 适配器有参数映射；其余适配器拒绝非默认 effort。具体模型拒绝某个档位时直接显示错误，不静默忽略。运行中禁止切模型或 effort，防止旧会话在切换后写回。

## 记忆

```text
/remember short 当前任务确认过的发现
/remember long 跨任务可复用的经验
/memory 检索词
/forget <记忆id>
```

记忆放在数据目录 `memory.db`，有内容哈希去重、来源和时间。短期记忆按工作区与会话隔离；长期记忆按工作区隔离、跨会话检索。检索用英文词与中文双字片段，没有 embedding 调用。每轮最多检索 4 条、每条注入最多 1200 字；记忆位于稳定角色前缀之后。

执行代理会自动保存带 `worker-reported` 来源的短期检查点。长期记忆通过用户显式保存；模型工具只能写短期记忆，避免自动把未经核查的结论升级成长期事实。它实现了可复用记忆机制，没有复现 RSIAgent 的完整自主探索、Verifier 或论文实验。

## 独立工具层

OpenAI Chat Completions 和 Anthropic Messages API 成员默认接入真实 function/tool-use 循环：`read_file`、`list_files`、`web_search`、`web_fetch`、`memory_search`、`memory_save`。它们通过独立 `runtime.py` 执行，工具起止、输入、结果、错误都进入 trace。文件读取只限工作区与已授权路径，拒绝凭据和隐藏目录；网页只允许公开 HTTP(S)，拒绝本地地址并检查重定向。

默认最多 6 个工具回合，再要求模型作答。单回合最多 16 个调用，单个结果注入最多 6000 字，明确标注截断。API 工具模式采用完整 JSON 响应，所以工具事件可实时出现，模型正文按模型调用结束显示。`model_overrides.<id>.tools_enabled=false` 可为不支持函数调用的端点使用原有纯文本流式路径；effort 同样生效。

搜索默认使用免 key 的 Bing RSS；返回 URL 和摘要，不保证召回质量。可设 `tools.search_provider="brave"` 并给运行中枢的进程提供 `BRAVE_SEARCH_API_KEY`。网页的 403、超时、无结果都显式返回错误，不能当成“资料不存在”。此次真实测试取得 5 条搜索结果，但召回偏宽；官方文档页面读取被远端以 403 拒绝。未宣称该页面已成功读取。

CLI 成员保留各自原生工具，不重复加一套工具协议。独立工具层不包含任意 shell 或文件写入工具；需要执行修改的任务使用 CLI 成员。

## Token 与缓存

- 新配置默认历史 16 条、历史正文 12000 字、前缀 16000 字。原始消息不删改，进入模型的历史有单独预算；显式配置 `0` 仍表示关闭相应上限。
- 当前请求不再同时进入历史和本次消息。原生记忆续接只补充上次已交付游标后的群聊增量，不重发完整历史；执行工作流使用任务、依赖摘要和检查点，不使用全群转录或共享原生会话。
- 不使用额外 LLM 做例行压缩、挑选下一个发言人或每步重新规划。新安装默认关闭自动 @ 接力，避免无意义扇出；保留已有用户配置。
- 缓存命中率仅统计服务商明确返回 cache 用量的调用。未报告显示未知，并提供未报告调用数；本地前缀复用不算服务商命中，也不声称节省了真实账单。
- 会话预算现在包含输出 token。预算是在调用边界检查的软上限；并发在途请求和未报告用量意味着它不是严格计费封顶。

## 安装与验证

探测支持 npm 包 `bin` 元数据；失效的启动器会尝试后续候选，`--version` 失败的程序不会标成可用。这里的可用表示 CLI 启动探针通过，不代表已验证登录、额度或模型访问。一个 CLI 足以启动；没有 CLI 也可启动界面添加 API 模型。

源码验收命令：`npm test`、`npm run selftest`、`npm run smoke`、`npm run pkg-e2e`、`npm run check`。测试使用临时数据，不修改现有 `config.json`、消息库或第三方 CLI 的配置。修改前文件备份整理后位于开发目录 `backup/code-snapshots/20261028-original/`，不随 npm 包发布。

真实 Codex exec 连接已返回 `CODEX_CLI_OK`，未调用工具；服务商返回输入未命中 7250、缓存读 12416、输出 9 token。该请求用于连接验收，不是 Token 节省对照实验，也不代表所有模型与端点均已通过。

## 参考及采用边界

- [OpenAI 非交互模式](https://learn.chatgpt.com/docs/non-interactive-mode)：采用 exec、JSONL 事件与 CLI 原生会话；本地 CLI help 与真实请求同时核对参数。
- [AutoGen Teams](https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/teams.html)：采用固定顺序讨论和显式终止边界，没有引入其框架依赖。
- [Anthropic 多智能体研究系统](https://www.anthropic.com/research/multi-agent-research-system)：采用执行上下文隔离、摘要交付和按任务控制调用量，没有搬用其性能数字。
- [RSIAgent 原仓库](https://github.com/AetherLabsAI/RSIAgent)：参照可复用经验与执行记忆的分层思想，没有将本地演示等同于论文中的完整系统。
