# 文档索引

按「你在干什么」查，不按文件名查。

## 上手与日常

| 文档 | 内容 |
| --- | --- |
| [../README.md](../README.md) | 项目入口：定位、特性、快速开始、命令表 |
| [manual.md](manual.md) | **完整手册**（原 README 全文）：缓存命中原理、权限准入、流式输出、MCP 接入、OTel 用量、排错 |
| [ops.md](ops.md) | 运维手册：启动/停止入口、数据目录与配置来源、日志位置、常见故障处置 |

## 接入与设计

| 文档 | 内容 |
| --- | --- |
| [agent-integration.md](agent-integration.md) | 把一个 Agent 接进中枢的完整流程：MCP 注册、各 CLI 的差异、鉴权与实例发现 |
| [roundtable.md](roundtable.md) | 圆桌模式的设计依据：固定顺序、硬轮数、每实例独立会话的理由与文献出处 |
| [packaging.md](packaging.md) | 打包与便携化：`files` 白名单、数据目录迁移、只读安装、`CLAUDELINK_HOME` |

## 版本变更

| 文档 | 内容 |
| --- | --- |
| [upgrade-0.5.md](upgrade-0.5.md) | 0.5.0：更名 Chorum、直连 API 模型的四个修复、工作目录与版本号问题 |
| [upgrade-0.4.md](upgrade-0.4.md) | 0.4.0：界面改造、实例与版本核对、已复现 bug 清单 |
| [upgrade-0.3.md](upgrade-0.3.md) | 0.3.x：圆桌、分层记忆、`/model` `/effort` `/tools` |

## 交付物

| 文档 | 内容 |
| --- | --- |
| [ppt/Chorum产品介绍/](ppt/Chorum产品介绍/) | 产品介绍 PPT（12 页）与设计说明 `DESIGN.md` |

## 本地保留、不入库

以下内容留在工作目录但被 `.gitignore` 排除，公开仓库里不会出现。放这里的理由是「查历史时有据可查」，不是给外部读者看的。

| 路径 | 内容 |
| --- | --- |
| `history/` | 交接记录、诊断日志、整理前的原始文档 |
| `reports/` | 阶段性验收报告（validation-0.3 / 0.3.1 / 0.4） |
| `trace-spec.md` | 执行流程（trace）字段与事件规格，含真实样本 |
| `m1-patch.md` | 早期一次补丁的说明 |
| `优化清单-2026-10.md` | 优化候选清单 |
| `外部对标-2026.md` | 与外部同类产品的对标记录 |
| `多智能体协作-token成本技术报告.md`、`缓存命中成本报告.md` | 带真实用量与费用的成本分析 |

新增文档时：面向使用者的放本目录根，面向历史的放 `history/`，并在上表登记一行。

> `manual.md` 与 `ops.md` 里有 3 处链接指向更早期的目录布局（`../目录导航.md`、`.verify/organization-20261028/move-plan.json`），这些目标在本次整理之前就已不存在。为保证历史文档的原样，未改动原文；新写的文档请只引用上表列出的文件。
