# AI Agent 接入逻辑（自动识别 / 装配 / 运行）

本文件记录 ClaudeLink 如何识别本机已安装的 Agent CLI、按什么规则装配、以及每个 Agent 的非交互接入方式。检测与装配由 npm 包的 bin/ 完成，运行由 hub.py 的 runner 完成。

## 1. 识别规则

按顺序探测，命中即用（2026-10-25 便携化后，**注册表与代码里都不允许出现机器专属绝对路径**）：

1. 环境变量 `CLAUDELINK_<NAME>`（如 `CLAUDELINK_CLAUDE`）→ 来源标记 `env`
2. `config.json` 的 `agents.<id>.exe`（用户显式指定，允许 `%VAR%`；**失效路径会被跳过**）→ `config`
3. PATH（`<bin>` 裸名 + Windows 的 `.exe/.cmd/.bat` 变体）→ `path`
4. 注册表里的便携位置（`%APPDATA%/npm/…`、`%LOCALAPPDATA%/Programs/…`、`~/.local/bin`）→ `known-dir`
5. npm 全局根（`npm prefix -g` 推导；Windows 上经 `cmd /d /s /c` 执行）→ `npm-root`
6. 通用搜索根（npm 前缀、`%APPDATA%\npm`、`~/.local/bin`、`~/.bun/bin`、`~/.volta/bin`、
   `~/.cargo/bin`、`%LOCALAPPDATA%\Programs`、`WinGet\Links`、`/usr/local/bin`、`/opt/homebrew/bin` …）→ `search-root`
7. `scanDirs` 递归扫描（Codex 桌面版按版本目录散落在 `%LOCALAPPDATA%\OpenAI\Codex\bin\<hash>\`，取最新）→ `scan-dir`

> 检测结果写入 **`~/.claudelink/agents.detected.json`**（`detect --write` / postinstall / start 都会写）；
> **用户自定义 Agent 注册表是另一个文件 `~/.claudelink/agents.json`（工具只读，永不覆盖）**。
> hub.py 在「env → config」之后读检测缓存 —— 这是「安装时自动识别」与运行时之间的桥。

命中后再跑一次 `--version`（4 秒超时）拿版本号；版本取不到只显示 ?，不影响装配。
`.js` 与无扩展名的 node 入口一律用 `node <file>` 调用；`.cmd/.bat` 经 `cmd /d /s /c` 调用，
避免 Node 直接把 `.cmd` 当可执行文件报错（否则连 `npm root -g` 都会 ENOENT）。

判定：

| 支持级别 | 含义 | 是否装配 |
| --- | --- | --- |
| builtin | hub.py 有专用 runner | 是 |
| generic | hub.py 通用 runner + 已验证参数 | 是 |
| detect | 只识别 | 否（报告原因） |

可用 Agent 少于 2 个时，detect/setup/start 一律输出「没有识别到AIAgent」并退出码 1，不启动服务。

## 2. 装配规则（setup）

- 检测到且受支持：agents.<id>.enabled=true，exe 写绝对路径；已有配置项（模型、profile、sandbox 等）保留
- 检测不到：enabled=false（配置保留，不删）
- 已识别但未支持：不写入 agents，只在输出里说明原因
- dispatch.order **保留旧顺序**（只丢弃已不存在的成员），新成员按注册表顺序追加
- 写前备份 config.json.bak-detect-<时间戳>，失败可回滚

## 3. 运行：runner 分层

- run_claude / run_codex / run_codebuddy / run_dsh：专用 runner（流式 JSON、会话续接、usage 统计）
- run_generic_cli：通用 runner，按 agents.<id>.generic 描述执行：

~~~json
"generic": {
  "args": ["-p", "{prompt}", "--output-format", "json"],
  "stdin": false,
  "output": "json",
  "text_field": "response",
  "list_field": "",
  "session_field": "session_id",
  "resume_args": [],
  "create_args": []
}
~~~

| 字段 | 说明 |
| --- | --- |
| args | 参数模板，{prompt} 为提示词占位 |
| stdin | true 时提示词走 stdin（绕开 Windows 命令行长度限制） |
| output | text 纯文本；json 结束时一个 JSON；jsonl 逐行 JSON |
| text_field / list_field | 正文提取：点路径 / 消息数组（取 role=assistant 的 content） |
| session_field | 从输出里按点路径取会话 id（**不支持正则**） |
| resume_args / create_args | 续接 / 新建会话参数模板（{session} 占位） |

提取不到正文时退回原始 stdout，保证消息能落地；完全无输出才报错（带退出码与末尾三行）。

## 4. 各 Agent 的非交互接入（2026-10 文档/实测结论）

| Agent | 可执行名 | 非交互调用 | 输出 | 会话 | 级别 |
| --- | --- | --- | --- | --- | --- |
| Claude Code | claude | hub 专用 runner：-p --output-format stream-json --include-partial-messages，prompt 走 stdin | stream-json | --resume <id> | builtin |
| Codex CLI | codex | hub 专用 runner：app-server JSON-RPC | JSON-RPC | thread id | builtin |
| CodeBuddy | codebuddy | hub 专用 runner：-p --output-format stream-json，prompt 走 stdin | stream-json | --session-id / --resume | builtin |
| DeepSeek Harness | dsh | hub 专用 runner：headless profile，prompt 走 DSH_TASK 环境变量 | 纯文本 | 无 | builtin |
| Gemini CLI | gemini | gemini -p "<prompt>" --output-format json | JSON {response, stats} | -r <id>（json 模式不返回 id） | generic |
| Qwen Code | qwen | qwen -p "<prompt>" --output-format json | JSON {messages:[{role,content}]} | --session-id <id> 新建 / --resume <id> | generic |
| Cursor Agent | cursor-agent | cursor-agent --print --output-format json "<prompt>" | JSON {result, session_id} | --resume <chatId> | generic |
| GitHub Copilot CLI | copilot | copilot -sp "<prompt>"（只输出回答） | 纯文本 | 无 | generic |
| Aider | aider | aider --yes-always --no-pretty --no-stream --no-check-update --no-show-model-warnings --analytics-disable --message "<prompt>" | 纯文本 | 无 | generic |
| Amp | amp | amp -x + stdin 传 prompt | 纯文本（最后一条消息） | 无 | generic |
| Goose | goose | goose run -t "<prompt>" | 纯文本 | 无 | generic |
| OpenCode | opencode | opencode run "<prompt>" --format json | NDJSON（字段待实测） | --continue / --session | detect |
| Crush | crush | 待实测 | 待实测 | 待实测 | detect |
| Continue CLI | cn | 待实测 | 待实测 | 待实测 | detect |
| Ollama | ollama | 本地模型运行器，不是 Agent | — | — | detect（建议按 HTTP 模型接入 127.0.0.1:11434/v1） |

注意：

- Gemini / Qwen / Cursor / Aider / Copilot 的 prompt 走命令行，Windows 下约 32KB 上限；群聊 prompt 常达 4 万字，超长会被截断或失败。Amp 走 stdin 不受此限。
- generic 成员默认 supports_native_memory=false（除了配置了 resume_args/create_args 的），记忆由群聊窗口掌管。
- 新 Agent 要升级为 generic，只需在注册表里补 generic 描述，不需要改 hub.py。

## 5. 终端命令

~~~bash
claudelink-hub detect                       # 识别
claudelink-hub setup                        # 装配 config.json
claudelink-hub setup --attach               # 把已识别的 Agent 接到 ClaudeLink MCP（默认 dry-run）
claudelink-hub setup --attach --yes         # 真正注册
claudelink-hub setup --detach --yes         # 精确移除 claudelink 条目
claudelink-hub env --show                   # 用户级 CLAUDELINK_* 变量
claudelink-hub env --set CLAUDELINK_PYTHON=<路径> --yes
claudelink-hub start                        # 检测 → 装配 → 启动 → 打开 Web UI
claudelink-hub ui                           # 只打开已运行的页面
~~~

## 6. 自动接入 ClaudeLink MCP（attach）

`setup --attach` 把「已识别的 Agent CLI」注册成 ClaudeLink 的 MCP 客户端。它**只做 MCP 注册**，
不写 config.json、不改 hub.db、不碰第三方 CLI 的其它配置。

### 6.1 两种模式

| 场景 | 行为 |
| --- | --- |
| 默认（无 --yes、无 CLAUDELINK_AUTO_ATTACH=1） | **只打印将要执行的命令**，不执行任何外部命令 |
| `--yes` 或 `CLAUDELINK_AUTO_ATTACH=1` | 真正执行 `mcp add` / `mcp remove` |

`npm i -g` 时的 postinstall **默认只提示**（"检测到 N 个 Agent，运行 claudelink-hub setup --attach 可自动接入"）；
只有环境变量 `CLAUDELINK_AUTO_ATTACH=1` 才自动执行，且任何失败都不阻断安装。

### 6.2 判定与执行规则

- 调用一律用 **detect 解析出的绝对路径**（codex 桌面版不在 PATH，只能靠 scan-dir 找到）；
  裸名只在注册表没有解析结果时回退。
- 每条 `mcp *` 命令 **10 秒超时**（`CLAUDELINK_ATTACH_TIMEOUT` 可调，测试用）。
- 先跑 `mcp list` 再决定动作，状态分四种：

| 状态 | 含义 | 动作 |
| --- | --- | --- |
| attached | 有条目 **且** 命令含 `claudelink-server` / `server.js` | 跳过（幂等） |
| absent | 没有 `claudelink` 条目 | 执行 add |
| unknown | list 超时 / 非 0 退出 | **不做任何改动**，也不提示"未接入"，避免重复注册 |
| stale | 有同名条目但命令不是 ClaudeLink | 不改不删，提示手工处理 |

- 健康检查（√ / ✗ / Connected）只作展示，不参与"是否接入"的判定。
- 检测到 `missing` / 不支持的 Agent 时**不执行任何命令**，只在 dry-run 里列出。
- 以 root 身份运行（`SUDO_USER` 或 `HOME=/root`）时直接拒绝，避免写进 root 的家目录。
- 环境变量原样继承：`CLAUDE_CONFIG_DIR`、`CODEX_HOME` 指向哪里，注册就写到哪里。

### 6.3 各家的注册命令（注册表 `mcp` 字段）

| Agent | list | add | remove |
| --- | --- | --- | --- |
| claude | `mcp list` | `mcp add --scope user claudelink -- {server}` | `mcp remove --scope user claudelink` |
| codebuddy | `mcp list` | `mcp add -s user claudelink -- {server}` | `mcp remove -s user claudelink` |
| codex | `mcp list` | `mcp add claudelink -- {server}`（无 --scope） | `mcp remove claudelink` |
| dsh | — | `mcp: null`（实测没有 mcp 子命令） | — |

`{server}` 默认替换成 `claudelink-server`，自定义部署可用 `CLAUDELINK_MCP_SERVER` 覆盖。
要支持新 Agent，只需在注册表里加 `mcp: {list, add, remove}`，**不用改代码**；
没有该字段的 Agent 会打印"未支持自动接入"，不会猜命令。

### 6.4 账本与回滚

- `<数据目录>/attach-state.json` 记录 `{agent, cmd, at, server}`：只记我们注册过什么，**不含任何密钥**。
- `--detach --yes` 用各家自己的 remove 子命令精确移除，并从账本删掉对应条目。
- 账本只是审计/回滚的辅助；"是否已接入"始终以 `mcp list` 的实时结果为准。

### 6.5 手工步骤（不支持自动接入时）

- **dsh**：没有 `mcp` 子命令，只能用 `dsh --profile <名>` 走 hub 自己的 runner（见第 4 节）。
- 其它未支持/未识别的 CLI：在它的 MCP 配置文件里手动加一条
  `claudelink` → 命令 `claudelink-server`，参数留空。
- 想确认是否接好：运行该 CLI 的 `mcp list`，应看到 `claudelink: claudelink-server ... Connected`。

## 7. 并发保护（同时跑两个 claudelink-hub）

CLI 会写的状态文件都做了「文件锁 + 写前比对」：`bin/util.js` 的 `withFileLock` / `updateJsonLocked`。

| 文件 | 谁写 | 保护方式 |
| --- | --- | --- |
| `config.json` | `setup` / `start` / `--no-setup --port` | 目录锁内「重读 → 重算 → 原子写」，写前比对文本（CAS），冲突重试 3 次 |
| `attach-state.json` | `attach` / `detach` | 锁内合并本次增删，不再用一开始的快照覆盖 |
| `~/.claudelink/env.json` | `env --set/--unset` | 锁内只改本次涉及的键 |
| `~/.claudelink/agents.detected.json` | `detect --write` / `doctor` / `start` / postinstall | 写缓存加同一把锁（含旧缓存迁移的 rename） |
| 第三方 MCP 配置 | `attach --yes` | 整个「探测 → 写 → 记账」事务一把锁，两个 attach 不会写出重复条目 |
| `config.json`（Python 侧） | `hub.py` 的 `save_config` | 同一把目录锁；锁内重读磁盘，把「内存快照 → 当前内存」的差异按三方合并盖回去 |

- 锁是 **目录锁**（`.<文件名>.lock/`，mkdir 在 Windows/POSIX 都原子）；持有者的 `pid` 已死或超过 30s 视为残留并回收。
- 无竞争时行为不变：内容没变化就不写盘（`setup` 会提示「内容无变化，未改动文件」）。
- 应急开关：`CLAUDELINK_NO_LOCK=1` 关掉锁（只在排障时用，会退回「可能丢更新」的老行为）。
- 等待锁超时会明确报错并给出可操作提示，绝不静默继续写。

### 7.1 hub（Python）这一侧

`hub.py` 的 `save_config()` 用的是**同一把锁、同一套协议**（`.<文件名>.lock/` + `owner.json`），所以 CLI 和中枢抢的是同一把锁：

1. 拿锁（最多等 3s；拿不到就降级为「直接读-改-写」，原子替换兜底）；
2. 读磁盘上的当前配置；
3. **三方合并**：以磁盘为准，只把 hub 自己改过的键（内存快照 → 当前内存的差异）盖上去；
4. 写临时文件 `config.json.tmp-<pid>` → `fsync` → `os.replace`；
5. 合并结果回写内存，并更新下次合并的基线。

于是「中枢运行期间跑了 `setup`」不再丢改动：CLI 改的端口/成员/顺序保留，中枢改的 relay/权限也保留。内容没变化时完全不碰文件。

**已知的残余风险**：

1. 中枢内存里仍是启动快照，新配置要重启才对界面生效（`setup` 会提示这一点）。
2. 同一进程内的多线程读改写仍只有 `CONFIG_LOCK` 保护（历史遗留）；跨进程已由文件锁覆盖。
3. 两个 `start` 仍可能同时拉起进程，但只有一个能占住端口；失败的那个会再探一次健康检查，确认别的进程已经起来就按成功返回。
