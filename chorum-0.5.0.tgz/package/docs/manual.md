# Chorum · 本地多智能体协作中枢

> 这是 Chorum 的**完整手册**（原 README 全文，结构与历史内容一起保留）。
> 想先跑起来看 [README](../README.md)；运维看 [ops.md](ops.md)；打包与便携化看 [packaging.md](packaging.md)。
> 文中出现 `claudelink-hub` 命令的地方都可以换成 `chorum`（0.5.0 更名，旧命令名保留为别名）。

---

> 原名 `claudelink-hub`，0.5.0 起更名 **Chorum**（包名 `chorum`，命令 `chorum`，`chorum-hub` / `claudelink-hub` / `claude-hub` 作为别名同在）。

当前版本 **0.5.0**。[本轮的连通性修复、直连 API 模型的工具调用、更名与验收](upgrade-0.5.md)。

一句话定位：把本机已装的 AI Agent CLI（Claude Code / Codex / CodeBuddy / DeepSeek Harness…）和任意 OpenAI / Anthropic 兼容的 API 模型**装进同一条群聊**，可以发给全体、点名单聊、@ 接力、开圆桌、把一件事拆成持续执行的任务；所有轮次带工具调用、token 与缓存记录。

0.4 的界面改造与验收见 [升级说明](upgrade-0.4.md)；0.3 见 [升级说明](upgrade-0.3.md)。

```bash
chorum doctor                    # 体检：Agent / Python / 工作目录 / npm / 配置
chorum start                     # 装配并启动，打开 http://127.0.0.1:8787
chorum model add --label DeepSeek --style openai \
  --base-url https://api.deepseek.com/v1 --model deepseek-chat --key sk-…
chorum ask --to DeepSeek "读一下工作区里的问题清单，列出三条最关键的风险"
chorum model list                # 也可以全部在网页 / 终端版里操作
```

> 打包/便携化细节见 [`docs/packaging.md`](packaging.md)，Agent 接入细节见
> [`docs/agent-integration.md`](agent-integration.md)。（交接文档与 `tools/` 只在开发仓库里，不随包发布。）

## 启动

**用本地 npm 安装包安装**

当前版本只提供本地 `.tgz` 安装包，尚未发布到 npm 公共仓库。直接运行 `npm i -g chorum` 会请求公共仓库并可能返回 E404。先取得本项目生成的安装包，再在安装包所在目录执行：

```bash
npm i -g "./chorum-0.5.0.tgz"
chorum doctor               # 体检：Agent / Python / 工作目录 / npm 前缀 / 数据目录
chorum start                # 按检测结果装配 config.json 并启动，自动打开 http://127.0.0.1:8787
```

**从源码运行**

```bash
python hub.py               # 或 node bin/cli.js start
```

（Windows 源码目录下的 `start-hub.bat` 只是作者本地的快捷脚本，不随 npm 包发布；通用入口就是上面的两条命令。）

- 关掉控制台窗口即停止服务。
- 也可以点页面右上角的「关闭」键停止服务（会先中断正在跑的轮次、结束成员子进程）；想禁用这个键，把 `config.json` 的 `server.allow_shutdown` 设为 `false`。
- 只监听 `127.0.0.1`，不对外网开放。
- **本地 API 默认要 token**：启动时生成/读取数据目录的 `hub.token`（0600），页面自动注入，TUI / CLI 自动读取；`/api/health` 免 token。`server.auth: false` 可临时关闭 token（Host/Origin 校验仍然生效）。
- 首次运行会按检测结果生成 `config.json`；数据目录（config/DB/日志/上传）默认在包目录，系统级只读安装会自动落到 `~/.claudelink-hub`（可用 `CLAUDELINK_HOME` 指定，见 `docs/packaging.md`）。

## 终端版（不开浏览器）

```bash
python hub_tui.py          # 用能跑 hub.py 的那个解释器（3.9+）；不确定就用 CLAUDELINK_PYTHON 显式指定
```

零依赖，直连同一个中枢（`/api/state` + `/api/stream`），不轮询。中枢没跑会自动拉起（`--no-start` 可关掉）。

- 键位：Enter 发送，←/→ 切换目标，↑/↓ 翻发送历史，Ctrl+R 搜索历史，鼠标滚轮上下查看，Ctrl+C 退出
- 消息区支持 Markdown：加粗、斜体、行内代码、围栏代码块、标题、列表、引用、链接；零依赖，流式输出也会实时渲染
- Windows Terminal 默认 `intenseTextStyle="bright"`，会把粗体渲染成亮色；要真正的粗体，在 `settings.json` 的 `profiles.defaults` 里设为 `"bold"` 或 `"all"`
- 命令：`/all`、`/stop`、`/relay`、`/interrupt 1`、`/retry <消息id>`、`/think`、`/help`
- 圆桌：`/round` 在终端里按向导选成员、排发言顺序、给每个成员指定角色名和系统提示词，再跑固定轮数；`/round stop` 暂停当前发言（圆桌保留），`/round resume` 继续，`/round status` 查看，`/round again` 载入上次配置。圆桌不复用 `relay`/`dispatch`，发言顺序完全由你指定（见下文「终端圆桌模式」）
- 非交互：`--dump 50` 打印最近 50 条，`--check` 输出一行健康 JSON，`--render-once` 渲染一帧
- 多行粘贴走 bracketed paste（Windows Terminal 支持），输入里的换行显示为 `↵`
- 斜杠命令：任何装载了 claudelink MCP 的客户端都能用 `tui` prompt（CodeBuddy `/claudelink:tui`，Claude Code `/mcp__claudelink__tui`）；不支持 prompt 的客户端直接调用工具 `open_terminal`
- 升级 claudelink 包会覆盖 `dist/`，重跑 `python tools/mcp-tui/install.py` 即可恢复

### 终端圆桌模式（`/round`）

给终端版单独加的一条「开会」路径：选多个 CLI，按你指定的顺序发言，每个成员有自己的角色名和系统提示词，跑固定轮数。它与群聊里的 `relay`（@ 点名接力）和 `dispatch.mode`（全体/顺序/并行）完全独立：圆桌回合不会被 `@` 打断，也不会改变你的全局接力开关。

1. `/round` → 问「开启多个 CLI 角色多轮会话？」；`y` 新建，`l` 载入上次配置到设置页。
2. 按编号/名字选成员，**输入顺序就是发言顺序**（如 `3,1,2`）。**同一个 Agent 可以重复**（如 `3,3,1`），每个出现都是一个独立实例：独立的角色/系统提示词；勾了原生记忆时各自有独立的 `--resume` 会话，默认中枢记忆则每轮都是无状态调用。
3. 选完成员直接进入「圆桌设置页」：↑/↓ 选择，`e` 改角色，`p` 改系统提示词（多行可粘贴；默认角色=成员名、提示词为空），`a` 追加实例，`d` 删除，`u`/`j` 调顺序，`r` 轮数，`t` 议题，`n` 切换新会话，Enter 开始。
4. `/round stop` 暂停当前发言（圆桌保留，不退出），`/round resume` 从下一位继续；`/round status` 看进度，`/round again` 把上次配置载入设置页再改。暂停的回合如果被中断，会重跑该位；已经跑完的圆桌再 `/round resume` 会追加一轮。

实现上，每位成员的回合直接走中枢的 `_run_agent`（`trigger_kind=roundtable`），只把前一位的回复留在会话历史里给下一位看；角色设定会同时进入稳定前缀和 CLI 的真实系统提示（Claude / CodeBuddy / API 模型 / dsh；Codex 与 generic 没有系统提示入口，走 prompt 顶部的系统级块）。每个实例用独立的 slot（如 `codebuddy`、`codebuddy#2`）做运行时身份，原生会话/锁/子进程都按 slot 分开。默认新开一个会话，避免和现有群聊的历史混在一起。

设计依据（细节见 `docs/roundtable.md`）：AutoGen 的 `round_robin` + `max_round` 说明固定顺序/硬轮数最可预测；CAMEL 的 inception prompting 强调角色边界与终止条件；ChatDev 的 chat chain 说明阶段化顺序比自由抢话稳定；Du et al. 的多智能体辩论表明「多轮批评-修正」能提升事实性与推理；MAST 的失败分类把「违反角色设定」「步骤重复」「不知道何时停」列为主要失败模式，所以这里默认有硬轮数、角色约束和随时可停。

同一 Agent 多实例的依据：AutoGen 要求同一 GroupChat 内成员名唯一，重复名字会让发言归属/路由变歧义，所以这里用 `codebuddy`、`codebuddy#2` 这样的 slot；Solo Performance Prompting（Wang et al., NAACL 2024）表明单个模型用多个细粒度 persona 做多轮自协作，能在复杂任务上带来收益；Inner Committee 模式同时提醒：persona 切换有提示与上下文成本、同一模型在各 persona 下有相同盲点、长对话会 persona drift。因此这里让每个实例拥有独立 CLI 会话，但默认仍共享讨论记录；如果发现同模型实例互相附和，优先把角色提示写得更具体、把轮数控制在 2–3 轮，而不是盲目加实例。

成本提醒：圆桌是 N 个成员 × R 轮 = N×R 次独立 CLI 调用，每个 CLI 还会带自己的会话上下文；先用 2 轮、3 个成员试。纯讨论如果不需要 CLI 隔离，单上下文多角色会更便宜（见 `docs/多智能体协作-token成本技术报告.md`）。

## npm 安装与自动识别（推荐入口）

按上面的 `.tgz` 命令完成全局安装后，使用以下命令识别与装配成员；这些命令不需要从公共仓库下载本项目：

~~~bash
claudelink-hub detect        # 只识别：列出 Agent、版本、路径、是否受支持
claudelink-hub setup         # 按识别结果写 config.json（写前自动备份）
claudelink-hub start         # detect → setup → 启动中枢 → 打开 http://127.0.0.1:8787
claudelink-hub ui            # 中枢已在运行时，只打开页面
~~~

- 识别对象：Claude Code、Codex CLI、CodeBuddy、DeepSeek Harness、Gemini CLI、Qwen Code、Cursor Agent、Copilot CLI、Aider、Amp、Goose、OpenCode、Crush、Continue、Ollama
- 已识别但 hub 还不支持的会明确列出原因，不会静默装配
- 一个可用 CLI 即可运行；未检测到 CLI 时也可启动网页添加 API 模型。启动探针不代表登录和模型访问已经通过。
- start 支持 --port 8787、--no-open、--no-setup、--detach、--config <路径>
- 需要 Python 3.9+（自动查找：`CLAUDELINK_PYTHON` → `py -3` → PATH → 常见的 conda/官方安装目录；可用 `CLAUDELINK_PYTHON` 指定）
- 各 Agent 的非交互调用方式与会话恢复参数见 docs/agent-integration.md
- 本地打包：npm pack，产物 claudelink-hub-<version>.tgz

## 成员 CLI 的路径：全部走环境变量

每个成员的 CLI 路径都是**环境变量优先**，所以 CLI 升级/换安装方式时**改环境变量就行，不用动 `config.json`**（改完重启中枢生效）：

| 环境变量 | 一般不用设；设了会覆盖自动识别 |
| --- | --- |
| `CLAUDELINK_CLAUDE` | 留空 = 从 PATH / npm 全局根自动找 `claude` |
| `CLAUDELINK_CODEX` | 留空 = 自动找（含 Codex 桌面版的版本哈希目录，取最新） |
| `CLAUDELINK_CODEBUDDY` | 留空 = 自动找 `codebuddy` |
| `CLAUDELINK_DSH` | 留空 = 自动找 `dsh` |
| `CLAUDELINK_NODE` | 留空 = 用 PATH 里的 `node`（codebuddy / dsh 以 `node <入口>` 调用） |
| `CLAUDELINK_CLAUDE_SETTINGS_DIR` | 默认 `~/.ccm/settings`（ccm 的 profile 目录） |
| `CLAUDELINK_NODE` | 留空 = 用 PATH 里的 `node`；codebuddy / dsh 用它跑 JS 入口 |
| `CLAUDELINK_HOME` | 数据目录（config/DB/日志/上传）；只读全局安装会自动切到 `~/.claudelink-hub` |

> 取值顺序（JS 侧 detect 与 Python 侧 hub.py **一致**）：
> **环境变量 `CLAUDELINK_<ID>` → `config.json` 的 `agents.<id>.exe` → 检测缓存
> `~/.claudelink/agents.detected.json` → PATH → npm 全局根 → 常见安装目录 → 版本哈希目录扫描**。
>
> 注意两个不同的文件：`agents.detected.json` 是**检测缓存**（工具写），
> `agents.json` 是**你自己加 Agent 的注册表**（工具只读，永不覆盖）。

怎么改：在「系统属性 → 环境变量」里改用户变量（或 `setx CLAUDELINK_CODEBUDDY "新路径"`），**然后重启中枢**（`setx` 只对新进程生效）。

排错时先看中枢控制台启动时打的那几行 —— 它会打印每个成员**解析出来的真实路径**：

```
[hub] node: C:\Program Files\nodejs\node.exe
[hub] codebuddy: <npm 全局前缀>\node_modules\@tencent-ai\codebuddy-code\bin\codebuddy
```

2026-09-29 的 CodeBuddy 连不上就是这条链修好的：旧配置写死了 WorkBuddy 桌面版内嵌的 CLI
（其安装目录下 `resources/app.asar.unpacked/cli/bin/codebuddy`），那套安装被换成 npm 全局包之后路径就废了。

**注意**：换掉某个 CLI 的**二进制**（不是路径写法）之后，它在库里存的原生记忆（CLI 会话 id）通常已经作废，
下一轮会报「调用失败」。在成员面板点一次**重置会话**让那个成员开新对话即可
（CodeBuddy 那次就是这样：老会话是旧 WorkBuddy CLI 建的，新 CLI resume 不了）。

## 用法

- 左下角点某个成员 = 只跟他说话；点「全体」= 启用的成员都收到。
- 底部输入框 Enter 发送，Shift+Enter 换行。
- 左侧开关「允许 @点名 自动接力」：开时，某方回复里出现 `@claude` / `@codex` / `@codebuddy` / `@all` 会自动给对方起一轮，接力的最大层数在 `config.json` 的 `relay.max_depth`（默认 2）。
- 「重置会话」= 让该成员在**当前会话**里忘掉上下文重新开始；**「清空本会话上下文」** = 见下节。

### 清空本会话上下文

顶部按钮 **清空本会话上下文**（不可撤销）会清掉**当前会话**的：

| 清掉 | 保留 |
| --- | --- |
| 本会话的所有聊天消息（含错误卡、权限申请卡、ClaudeLink 镜像条目） | 公告板 / 共享上下文（`context.shared_context`） |
| 各成员**在本会话里**的原生记忆（CLI 的 `sessions`，按 `conv_id` 过滤） | 系统提示词与群聊协议（每轮由代码生成） |
| 消息上的高亮片段 | 准入授权、成员开关、模型配置、`config.json` 全部设置 |
| — | **其它会话的消息与原生记忆**（按会话隔离，不受影响） |

两个刻意的设计：

1. **不写入任何新消息**——清空后窗口是干净的（只在界面上留一行不落库的提示），不会因为"清空完成"这类事件把上下文又弄脏。
2. **不重复**：ClaudeLink 镜像用独立的 `seen_refs` 表记录已展示过的 `nexus:<id>`，清空消息不会清这张表，所以旧镜像条目不会被重新贴一遍；同 `ref` 重复投递也会被 `messages(ref)` 唯一索引挡掉。

## 窗口内的运维功能（全部手动触发，不做任何定时刷新）

### 布局（仿 VSCode）

| 区域 | 说明 |
| --- | --- |
| 最左**活动栏** | 竖排图标；点图标切侧栏面板，**再点当前项=收起侧栏**；最下方箭头按钮也可收起/展开（快捷键 `Ctrl+B`）。当前项有白色左竖条 + 高亮 |
| **侧边栏** | 四个面板：成员与模型 / 运行视图 / 公告板 / 筛选与检索。收起后主区变宽 |
| **底部状态栏** | 已连接·断开（点=重连）、中枢地址、成员 启用/全部、处理中数量、消息数·失败轮次、记忆来源、**缓存命中率**、**冷启动 N 人**（有才显示）、筛选 开/关、有新消息↓、跟随 开/关、接力 开/关、当前发送目标。除提示类外都可点，点了会跳到对应面板或直接切换 |

活动栏图标可自定义：改 `config.json` 里的 `activity_bar.items`，`icon` 支持内置键
`agents / pulse / bookmark / search / plug / chat / chevron / gear`，也可以直接写一段 `<svg>…</svg>`；
`action: "dialog"` 表示点它是弹窗（如「添加模型」）而不是切面板。改完重新加载页面即可。

| 位置 | 功能 |
| --- | --- |
| 成员卡片 | 点名字=只跟他说话；**参与全体**（取消后广播不叫他）；**自动接力**（成员级，关掉后他的回复不再触发别人）；**重置会话**；**中断本轮**（正在处理时出现，kill 掉当前那轮）；自定义模型多一个**移除** |
| 成员卡片 meta | `正在处理（开始于 12:03:11）` / 原生会话 id 前缀 / `无原生会话`（`dsh`）+ **发 N / 收 M / 最近 HH:MM:SS** + 记忆来源 + **冷启动提示**（`⚠ 距上次 58.0 分钟（阈值 10 分钟）→ 本轮可能冷启动`，见「冷启动提示」） |
| 运行视图 | 成员数（启用/全部）、消息总数、失败轮次、正在处理的人、hub.db 体积（含 WAL）、镜像库最近读取时间、nexus 未读孤儿数、最近一条错误；**刷新健康** 按钮手动拉取 |
| 运行视图 | **收养孤儿消息**：把 ClaudeLink 里投给已失效 agent 的未读消息改挂到同名当前 agent（写前自动备份 nexus.db，不删消息） |
| 公告板 | 一段共享上下文，保存后注入每一轮的 prompt（分工/规则写这里） |
| 顶部工具条 | 关键字 + 成员 + 类型（我/回复/错误/事件/镜像）筛选，**应用筛选 / 清除筛选 / 跳到底部**；有新消息时只显示「有新消息（未跟随）」提示，不抢滚动条 |
| 顶部按钮 | **重新加载数据**（手动重拉一次全量）、**重连**（重建 SSE 连接）、**清空本会话上下文**（本会话的消息 + 本会话的原生记忆，保留公告与系统提示） |
| 输入框右侧 | **停止键**（圆形方块图标，快捷键 `Esc`）：有轮次在跑时变蓝高亮，点一下 = 中断所有正在跑的轮次 + 作废还在排队的轮次 + 关闭自动接力（防止互相点名又跑起来）。空闲时置灰 |
| 输入框上方 | **冷启动横幅**（只在当前发送目标里有人要冷启动时才出现）：`本次将发给 3 人，其中 2 人本轮大概率冷启动：Claude（会话已变）、Codex（距上次 41 分钟）`。发送前看到就能改成只 @ 热成员（见「冷启动提示」） |
| 输入框下方 | 使用说明栏：**点整条即可收起 / 展开**（收起后只留 `▸ 说明（点击展开）`，状态记在本地） |
| 错误气泡 | **重试这条**：用原始 prompt 重发同一轮 |
| 侧栏开关 | **跟到底部**：默认关闭；只有勾上才会自动滚动 |
| 每条消息 | **改写 / 删除 / 整条高亮 / 重试**：与状态文字同字号同灰色、无边框，鼠标移入该条消息才出现（平时 opacity:0 且 pointer-events:none，防误触） |
| 每条消息 | **用鼠标选中文字** → 弹出「高亮选中」；**把整条都选中 = 整条高亮**（与「整条高亮」按钮同一表示）。片段以 `【★重要★ 选中的文字 ★】` 进上下文，整条则以 `★重要★` 前缀进上下文 |
| 每条消息 | **「清除本条高亮」浮现在光标上**：鼠标移到高亮处（片段 `.hlseg` 或整条高亮的气泡）时，按钮在光标位置弹出并**停在原地**（不再跟着光标跑，可以直接点它）；在同一条消息内移动不会消失，离开该条或滚动列表才收起。没有高亮的消息不显示它，只显示「整条高亮」 |
| 筛选面板 | 勾 **只看高亮** 可单独列出所有被标记为重要的消息 |
| 成员卡片 | **原生记忆** 勾选（仅 CLI 成员，默认不勾） |

## 上下文（记忆）归谁管

每个**会话**各自独立：切换会话就切换记忆，新建会话从空记忆开始，会话之间互不影响。
上下文有两种来源，每个成员二选一（默认窗口记忆）。

### 窗口记忆（默认）

中枢自己拼 prompt 发给成员，CLI 不带 `--resume`。拼的内容依次是：

1. 群公告（公告板里保存的那段）；
2. 该成员的角色说明与工作区权限；
3. 群聊记录（用户消息与各成员回复）；
4. 本次消息。

于是 **改写 / 删除某条消息 → 下一轮模型就看不到旧内容**（已验证：告知 41 → 改写为 88 → 模型答 88 → 删除后答「无」）。
全部成员一致：Claude / Codex / CodeBuddy / DeepSeek Harness / 自定义 API 模型。

> 第 3 段（群聊记录）不是每轮重新拼的，而是**按会话冻结、只往后追加** —— 这样 provider 的前缀缓存才命中得了。
> 机制与配置见下文「缓存命中」。

### 原生记忆（可选，仅 CLI 成员）

成员卡片上勾 **原生记忆** 后，该成员改用 **CLI 自己的会话**（`claude --resume <会话 id>` 那一套），
删改窗口消息**不会**影响它。只有确实需要 CLI 内部状态时才勾（默认不勾）。

`dsh` 不支持原生记忆：它的 headless profile 没有 `--resume`，每次调用都是新会话
（详见「成员是怎么被驱动的 → DeepSeek Harness」）。

### 记忆按会话隔离（2026-09-29）

`hub.db` 的 `sessions` 表主键是 `(agent, conv_id)`，即**一个成员在一个会话里各存一份原生会话 id**。所以：

| 你的操作 | 原生记忆会怎样 |
| --- | --- |
| 新建会话 | 新会话从**空记忆**开始，而且**不碰**任何已有会话的记忆 |
| 切换会话 | 记忆跟着切；切回去，那份记忆还在 |
| 成员卡片的「重置会话」 | 只清该成员在**当前会话**里的记忆 |
| 顶部「清空本会话上下文」 | 只清当前会话的消息 + 当前会话里的原生记忆 |
| 换模型 / 换 profile | 清掉该成员**所有会话**的记忆（理由见下） |

两条说明：

1. **为什么换模型要清所有会话**：CLI 的会话 id 绑在原模型（有时还绑端点）上，只清当前会话的话，
   切回别的会话照样会拿老会话去 `--resume`（2026-09-28 实测：Claude 从 `deepseek-f` 换到 `deepseek-p`，
   `--resume` 老会话 7 分钟无输出）。
2. **改动前的行为**：`start_new_session` 会调 `clear_all_sessions()`，即**新建会话把全部会话的原生记忆一起清掉**
   —— 那正是"会话之间互相影响"的根源，现已删除。

### 不受中枢管辖的记忆

有两层记忆在 `sessions` 之外，中枢隔离不了，也不打算隔离：

- **CodeBuddy 按工作目录存的记忆**（`~/.codebuddy/projects/<工作目录>/memory/`，模型自己写的项目事实）。
  它**不认 `--session-id`**：只要工作目录一样，新会话也会读到（实测：全新会话 id 在同一目录提问，
  照样答得出上个会话教的内容；换个工作目录就答「不知道」）。中枢所有成员共用 `workspace.cwd`
  （默认 = 中枢所在目录），所以这套记忆在各个会话之间是**共用**的。
  **这是有意保留的** —— 它承载项目事实、审计结论、规则，用着正合适。真想隔离只能给每个会话换一个工作目录，
  代价是它的文件工具相对路径会变、且读不到已经攒下的那批记忆（等于失忆）。
- **CLI 自己读的说明文件**（如 `CLAUDE.md`）同理，属于 CLI 的行为，中枢不介入。

### 高亮的语义

高亮不是纯装饰，而是"告诉模型这一段最重要"。它在上下文里长这样：

```
注：被【★重要★ … ★】包住的部分是用户用鼠标选中的重点内容，必须优先满足；整条前带 ★重要★ 的表示整条都重要。
[13:20:41] 用户 → 全体: 项目代号 【★重要★ PEACOCK ★】，交付日期 10 月 1 日。只回复：收到
```

- 只标记选中的片段；同一条可以多次选择，多个片段各自标记（头部显示 `★ 重要×N`）。
- 重叠选择会合并成一段；「清除高亮」清掉该条全部标记。
- 改写消息内容会**自动清除**该条高亮（文本变了偏移就错位，避免误标）。
- 高亮属于**窗口记忆**的一部分，所以它一改，冻结的群聊记录就必须重锚（见「缓存命中」）。

## 缓存命中（原理效仿 DeepSeek Harness）

两件事一起做：**provider 早就报了缓存命中量，中枢把它丢了**；而且 prompt 的写法让前缀缓存**必然不命中**。

### 口径：四个互不重叠的 token 桶

四个桶是**未命中输入 / 命中读 / 命中写 / 输出**，互不重叠。

- `in_tokens` = **未命中**的输入（含义已改，见下）；
- `cache_read_tokens` = 命中读（provider 直接从缓存里复用的部分）；
- `cache_write_tokens` = 命中写（provider 为后续复用而写缓存的部分）；
- `out_tokens` = 输出（本来就是独立的一列）。

**前三个相加才是 prompt 全量**，命中率 = `命中读 ÷ (未命中 + 命中读 + 命中写)`。

"未命中输入"这一项不能只按字段名取，得知道该端点的 `input` **含不含命中**。
这是**逐端点**的属性，不是逐协议的 —— 两个端点同是 Anthropic 协议，结论正好相反。
判定方法：同一 prompt 在缓存有效期内连发两次，看 `input` 会不会掉。

| 端点 | 第 1 次 | 第 2 次 | 结论 |
| --- | --- | --- | --- |
| `api.deepseek.com/anthropic`（Claude） | `input=892 read=0` | `input=252 read=640` | `input` 掉了 640 → **不含**命中，原样用 |
| CodeBuddy 的 Tencent 网关 | `input=28012 read=3072` | `input=28012` `read=27776` | `input` 一个字没变 → **含**命中，要减 |
| `api.deepseek.com/v1`（OpenAI 协议） | `prompt=892 hit=640` | `prompt=892 hit=640` | 同上，**含**命中 |
| Codex（app-server） | `inputTokens=11246 cached=10880 total=11248` | — | `cached` 是子集 → **含**命中 |

所以：**含命中时 `未命中 = input − 命中读 − 命中写`，不含时 `未命中 = input` 原样**。
配在 `agents.<名>.usage_input_includes_cache`（自定义模型配 `model_overrides.<id>`），
不配则按风格兜底（`anthropic`→不含、其余→含）。

> 这一项踩过坑：最初按"协议"划分，把 CodeBuddy 也当成"不含命中"，于是它恒显示 **50%**
> （`172032 ÷ (172385+172032)`），而真实命中率是 **99.8%**（`172032 ÷ 172385`）。配错就是这个后果。

**`dsh` 不报用量**（headless 只打最终回答），所以它永远显示「该 CLI 不报用量」。

> 口径变更**不静默**：`state.usage_convention` 与 `state.usage_convention_since` 记着分界时刻，
> 所有归集只统计分界**之后**的轮次。老行的 `in_tokens` 是旧口径、缓存两列恒 0，
> 混进来会把命中率淹掉（长会话上实测 1.85 亿 token 的旧数据把命中率压到 0.04%）。老行不迁移。

命中率显示在四处，都是**当前会话**的口径：

| 位置 | 长什么样 |
| --- | --- |
| 执行流程 · 每个模型调用步骤 | `已思考 N tokens（缓存命中 x · 未命中 y，命中率 z%）` |
| 左侧会话列表 · 每行 | `缓存 62%` |
| 运行视图 | 一行「缓存命中（本会话）」 |
| 底部状态栏 | `缓存 62%`，按命中率着色（≥60% 绿 / ≥20% 琥珀 / 其余红） |

只统计**已结算**的轮次（正在跑的那轮还没 rollup，算进去会显示一个假数字）。

### 让命中真的发生：按会话冻结群聊记录

原来的写法每轮都重拼：`角色前言（含 sender/target） + 权限 + 滑动窗口历史 + 本次消息`。
`sender`/`target` 在**第一行**，所以第 0 个字节每轮都不同 —— 前缀缓存不可能命中。

现在每个 (成员, 会话) 存一份**渲染好的** `prompt_cache.prefix`，下一轮**原样复用、只往后追加**；
易变的部分（谁说的、投递给谁、本次消息、auto 模式的调度指令）挪到 prompt **最后**，
缓存断点正好落在尾部，命中覆盖整个前缀。实测（自定义模型，prompt 完全由中枢拼）：

| 轮次 | 未命中 | 命中读 | 命中率 |
| --- | --- | --- | --- |
| 1（冷启动） | 15,182 | 0 | 0.0% |
| 2 | **136** | 15,104 | **99.1%** |
| 3 | 174 | 15,104 | 98.9% |

配置在 `context.cache_prefix`：

| 键 | 默认 | 含义 |
| --- | --- | --- |
| `enabled` | `true` | 关掉就退回老写法（每轮重拼群聊记录，命中率极低） |
| `reanchor_chars` | `160000` | 前缀超过这个字数就**重锚一次**（那一轮付一次未命中，之后重新稳定）；`0` = 永不重锚，prompt 会无上限增长，慎用 |

**什么时候会重锚**（都只影响一轮，之后重新稳定）：

1. **稳定输入变了** —— 角色文案、工作区权限、成员表、群公告、生效的 `history_limit`（按哈希判定）；
2. **超过 `reanchor_chars`** —— 从**最前面**砍到装得下（最新的对话最重要）；
3. **消息被改写 / 删除 / 改高亮** —— 前缀里的字节已经是**错的**（不只是过时），必须重锚，
   这样上文承诺的「改写立即生效」才守得住；
4. **换模型 / 换 profile** —— 缓存是绑模型的，字节一样也是另一个模型的缓存，留着只会让命中率**看着好看、实际全不命中**。

### `history_limit` 的语义变了

从「**每轮**注入多少条」变成「**重锚时**取多少条」。两次重锚之间前缀一直增长（这是缓存命中的前提），
上限由 `reanchor_chars` 兜着。`history_limit = 0`（不限）同样受 `reanchor_chars` 封顶。

### 勾了「原生记忆」的成员要注意

它们会让 CLI 用 `--resume` 把它**自己的会话**重发一遍，那份体量常常**远大于**中枢拼的 prompt ——
实测 codebuddy 一个 72,832 字的中枢 prompt，对上一次 409,382 token 的调用，多出来的约 38 万全是
CLI 自己的会话。也就是说，**这种成员的命中率主要由 CLI 自己的会话前缀决定**，不是中枢能改的；
中枢只保证自己拼的那段是追加型的。

不过这不等于命中率低：CLI 的会话本身也是追加型的，所以它照样命中得很高 ——
实测 codebuddy 在长期会话里每个内部调用 99.3%～99.8%（未命中只剩每步新增的那几百个 token）。

> 想让中枢这层成为主导（prompt 就是成员看到的全部输入），可以取消这几个成员的「原生记忆」。
> 代价是丢掉 CLI 自己的会话状态。

### 冷启动提示（界面上的「本轮可能冷启动」）

一轮里绝大部分 token 是 CLI 自己重发的会话，所以**缓存一冷，整条会话就按未命中全额计费**。
实测最贵的一笔：Claude 某一轮第 1 次调用未命中 82,122 token，单轮实付 ¥0.126
（该成员全天 ¥0.648 的 19%）。界面上三处会提示：**成员卡片 meta 行**、**发送区横幅**、
**底部状态栏**（都只统计当前发送目标里的人）。

两个判据：

| 判据 | 触发条件 | 措辞 |
| --- | --- | --- |
| ① 距上次调用超过阈值 | `a.cache_ttl_min`（缺省 `context.cache_prefix.cold_start_minutes`，默认 **10** 分钟） | 「**可能**冷启动」 |
| ② 会话变更 | 该成员当前会话 id ≠ 上一轮用的会话 id（重置会话 / 换模型 / 换 profile） | 「**全冷**」 |

**为什么 ① 只能说"可能"**：5/30/10 分钟（Anthropic / OpenAI / DeepSeek）是各家的**保证下限**、
不是淘汰时刻（DeepSeek 原话是"不再使用后自动清空"，尽力而为）。实测同一会话内：
隔 **6.9 分钟**第 1 次调用命中 86%，隔 **10.7 小时**只剩 5% —— TTL 夹在这两者之间，
但**采样不足以定死**，所以按启发式提示。判据 ② 才是确定的。

成员卡片长这样（`上周命中` 是**上一轮第 1 次调用的实测命中率**，事实值不是预测）：

```
Claude  运行中 · 发 3 / 收 4 · 最近 19:52:21 · 原生记忆
        ⚠ 距上次 58.0 分钟（阈值 10 分钟）→ 本轮可能冷启动
```

配置：`context.cache_prefix.cold_start_minutes`（全局，`0` = 关掉时间判据只留会话变更）；
真要接原生 Anthropic / OpenAI 端点，再给那个成员单配 `agents.<名>.cache_ttl_min`（5 / 30）。
本机三个 CLI 成员打的全是 DeepSeek，所以 10 就够。

数据来源是 `turns` 已有的列（`end_ts` / `session_id` / 四个 token 桶），**不加新列、不迁移**。
注意 `turns.agent` 存的是**显示名**（`Claude`），而 `sessions` / `messages` / config 用的是
**路由 id**（`claude`）—— 取数时要按 label 查，混用会静默查不到（本仓踩过一次，见 `hub.py:979`）。

> 相对时间（"距上次 N 分钟"）靠一个 60 秒的 `setInterval` 重算那三处 —— 前端没有别的周期性刷新。

## 工作区权限准入（每个成员独立）

每个成员有一个 `permissions.mode`，它决定实际传给 CLI 的参数；**不再用 prompt 假装权限**。

| mode | 含义 | 典型 enforcement |
| --- | --- | --- |
| `read-only` | 只读；不写文件、不跑会改变状态的命令 | Claude `--permission-mode plan --restricted`；Codex `readOnly`；CodeBuddy `plan` + 工具白名单 |
| `workspace-write` | 只允许工作区/授权目录写；工具可用 | Claude `auto`（分类器，非内核沙箱）；Codex `workspaceWrite`；CodeBuddy `acceptEdits` + 工具白名单 |
| `danger` | 不受限；与旧行为一致 | Claude/CodeBuddy `bypassPermissions`；Codex `dangerFullAccess` |

优先级：`agents.<名>.permissions.mode` → `permissions.mode` → 旧 `permissions.default`（`unrestricted`→`danger`，`workspace`→`workspace-write`）→ `workspace-write`。
启动日志会逐成员打印 `permission: <名>=<mode> (<enforcement>)`。

**双击成员卡片**打开该成员的设置面板：

### 面板里的可调参数（全部写回 `config.json`）

| 区块 | 参数 | 键 | 留空 / 0 的含义 |
| --- | --- | --- | --- |
| 成员开关 | 参与全体 | `agents.<名>.enabled` 或 `model_overrides.<id>.enabled` | — |
| 成员开关 | 自动接力 | `…​.relay` | — |
| 成员开关 | 原生记忆（仅 CLI） | `…​.native_memory`(库) | — |
| 上下文与限制 | 历史条数 | `…​.history_limit` | 留空=跟随全局；`0`=不限（整段历史） |
| 上下文与限制 | 单轮超时(秒) | `…​.turn_timeout_sec` | 留空=跟随全局；`0`=永不超时 |
| 上下文与限制 | 流式输出 | `…​.stream` | — |
| 上下文与限制 | 单次最大输出 | `…​.max_output_chars` | 选"无上限"=不截断正文 |
| 上下文与限制 | 生成上限 max_tokens（自定义模型） | `model_overrides.<id>.max_tokens` | 覆盖模型自身设置；带思考的模型建议 ≥4096 |
| 上下文与限制 | 温度（自定义模型） | `model_overrides.<id>.temperature` | 留空=不传该参数，用服务端默认 |
| 工作区权限准入 | 可读写 / 只读 / 移除 | `permissions.grants.<成员>` | 无额外路径授权；模式仍由 `permissions.mode` 决定 |
| 待审批申请 | 同意 / 拒绝 | `perm_requests`(库) | — |

面板里的输入框**留空即跟随全局**（占位符会显示当前全局值，例如 `全局:20`、`全局:不限`）。
CLI 成员的参数写 `agents.<名>`，自定义 API 模型写 `model_overrides.<模型id>`；点击「保存」是逐项即时落盘的，没有"确定"按钮。

| 区域 | 作用 |
| --- | --- |
| 已授权工作区 | 列表显示 `可读写 / 只读` + 路径；可一键切换读写级别、可移除。未设置时没有额外路径授权，但仍受 `permissions.mode` 约束 |
| 添加授权 | 手填路径（目录或单个文件）+ 选 `可读写 / 只读`；也有快捷按钮（当前工作目录、`D:\`、用户目录） |
| 待审批申请 | 模型索要权限时出现在这里，**同意 / 拒绝** |
| 成员开关 | 参与全体、自动接力、原生记忆、重置会话、中断本轮、移除模型 |

模型侧怎么被约束、怎么申请：

1. 每轮 prompt 会注入 `[工作区权限] 模式：<mode>（enforcement: <native/classifier/tool-allowlist/prompt-only>）`，
   以及可写/只读路径和申请语法 `[[PERM rw <路径>|<原因>]]`。
2. **Codex 是真拦截**：有 rw 授权时走 `workspaceWrite + writableRoots`；没有 rw 授权时按 mode 走 `workspaceWrite` 或 `dangerFullAccess`。
   只有 ro 授权不会再把 mode 回落成 danger。
3. **Claude**：`read-only` 用 `plan --restricted --permission-prompts none`；`workspace-write` 用 `auto --permission-prompts none`
   （分类器放行，不是文件系统沙箱）；`danger` 用 `bypassPermissions`。**CodeBuddy**：`read-only` 用 `plan` + 工具白名单；
   `workspace-write` 用 `acceptEdits` + 工具白名单；`danger` 用 `bypassPermissions`。`dsh`/generic 没有原生沙箱，标 `prompt-only`。
   如果某个 CLI 的 headless 模式不认这些参数，中枢会降级并写日志，不会静默改 danger。
   CodeBuddy 的 `-p` 若必须 `-y` 才能用工具，显式设 `agents.codebuddy.permissions.allow_bypass=true`；默认不静默提权。
4. 模型写出 `[[PERM rw D:\某目录|要写构建产物]]` → 中枢把它从正文里摘掉，生成一张**权限申请卡**（聊天里）并在成员面板列出；
   你点**同意** → 立刻写入该成员授权并记一条系统事件；点**拒绝** → 只记录拒绝，不授权。申请语法与批准逻辑对四方通用。

接口：`GET/POST /api/grants`、`GET /api/perms`、`POST /api/perms/request`、`POST /api/perms/resolve`。

## 流式输出（四类通道都支持）

| 成员类型 | 流式来源 | 取文本的方式 |
| --- | --- | --- |
| Claude | `--output-format stream-json --verbose --include-partial-messages` | `stream_event → content_block_delta → text_delta`，逐段推给前端；最终文本用 `result` 事件 |
| CodeBuddy | `--output-format stream-json --include-partial-messages` | 同上（同一套 Claude Code 事件协议） |
| Codex | `codex app-server`（stdio JSON-RPC） | `item/agentMessage/delta` 逐段推送；`item/completed(agentMessage)` 取最终文本；`turn/completed` 结束 |
| 自定义 API 模型 | 请求体带 `"stream": true` | OpenAI 兼容读 `choices[].delta.content`；Anthropic 兼容读 `content_block_delta.text_delta` |

- 前端会为该成员先建一个虚线气泡「输出中…」，增量到达就实时改写它；最终消息落地时替换掉。
- 增量推送有节流：距上次≥0.08 秒或新增≥8 字才广播一次，其余只更新本地缓冲——既流畅又不会把 SSE 打爆。
- 关闭「跟到底部」时流式更新**不会**抢滚动条（和普通消息一致）。
- 想看原始增量：`GET /api/state` 里每个成员带 `live` 字段（最近 400 字）。

## 文件 / 图片拖入

把文件直接拖到窗口任意位置，会出现整屏拖放层（图标 + “文件和图片拖动到此处即可上传” + “最多 50 个，每个 100 MB”）。
也可以：

- **Ctrl+V 直接粘贴**——截图工具复制的位图、资源管理器里 Ctrl+C 复制的文件、复制的图片文件都能粘；粘贴进来的会自动落到 `uploads\<时间戳>\剪贴板\` 下并改名（如 `粘贴-20260926-144500-1.png`）。
- 用输入框右侧的 **＋ 文件** 按钮选择。

松手/粘贴后逐个上传并解析，成功的会变成发送框上方的附件条，点 ✕ 可移除；发送时随消息一起给模型。
纯文本粘贴不受影响（检测不到文件时走浏览器默认行为）。

支持与解析方式：

| 类型 | 处理 |
| --- | --- |
| 文件夹 | 浏览器遍历目录，按相对路径逐个上传（等于一次拖入一批文件） |
| 压缩包 `.zip`（含 jar/epub/xlsx/pptx 这类 zip 容器） | 列出条目清单，并把包内文本类文件的内容抽出一段 |
| PDF | 用 `pypdf` 逐页抽文本（扫描件会提示未提取到文本层） |
| Word `.docx` | 优先 `python-docx`，没有库时退回 zip + `word/document.xml` 解析；旧版 `.doc` 提示另存 |
| Markdown / 文本 / 代码 / CSV / JSON / YAML… | 直接读取（自动尝试 utf-8 / gbk / big5） |
| 图片 png/jpg/webp… | 不解文本，只登记路径 |

解析进程与运行中枢的解释器解耦：`extract.py` 会优先挑一个 `import pypdf` 成功的解释器（例如 Codex 捆绑运行时自带的那个），找不到就用 stdlib 兜底，所以中枢本身不需要装任何解析库。

注入方式与限制：

- 用户消息的**正文**（模型上下文）会追加一段 `[附件]` 块：文件名、类型、大小、**本地绝对路径**、以及解析出的文本；而聊天窗口里显示的是你输入的原文（存在 `display_text`），不会刷屏。
- 图片会给 Codex 走原生 `localImage` 输入；其它成员通过路径 + `（图片文件…可用读取工具查看）` 的说明去读。
- 上限都在 `config.json` 的 `uploads` 段：`max_items`（默认 50）、`max_mb`（每个 100）、`max_text_chars_per_file`（单文件 2 万字）、`max_total_chars`（单条消息附件总量 12 万字）、`parser_python`（想强制指定解析解释器时填）。
- 文件落盘在 `<中枢目录>/uploads/<时间戳>/…`，「清空本会话上下文」**不会删文件**（只清消息与本会话的原生记忆）。

### 刻意不做的

不轮询（无 `setInterval`／不自动重绘／不自动滚动）、不自动重试、不做定时 auto-nudge、不做 Recovery Watcher、不提供 Kill all servers 与停止服务按钮、不删除任何消息来「修复」数据。

### 相关接口（便于脚本或排错）

```
GET  /api/state                全部状态（agents/messages/context/health）
GET  /api/health               健康 + nexus 孤儿计数
POST /api/interrupt            {agent}
POST /api/retry                {message_id}
POST /api/agents/toggle        {agent, enabled}     参与全体
POST /api/agents/relay         {agent, enabled}     成员级自动接力
POST /api/agents/memory        {agent, native}      原生记忆 / 窗口记忆
POST /api/messages/edit        {id, text}           改写（影响模型上下文）
POST /api/messages/delete      {id}                 删除（影响模型上下文）
GET/POST /api/context          {text}               公告板
POST /api/nexus/adopt          收养孤儿消息
POST /api/models | /api/models/delete | /api/models/test
POST /api/send | /api/relay | /api/reset | /api/clear
```

## 接入其他模型（模型管理）

左侧「＋ 添加模型」打开对话框，填完点「测试连接」确认通了再「保存并加入群聊」。保存后它就是一个正常成员：能收全体消息、能被定向、能被 @点名接力。

| 字段 | 说明 |
| --- | --- |
| 名称 | 群里显示的名字，也是 @点名 用的名字（如名称 `DeepSeek` → `@DeepSeek`） |
| 路由方式 | `Anthropic 兼容` 走 `/v1/messages`；`OpenAI 兼容` 走 `/v1/chat/completions` |
| Base URL | 例：`https://api.anthropic.com`、`https://api.deepseek.com/anthropic`、`https://api.openai.com/v1`、`https://ark.cn-beijing.volces.com/api/v3` |
| API Key | 该服务的 key；界面只回显掩码，真实值存在本地 `hub.db` |
| 模型名 | 传给它 API 的 `model` 字段 |
| 接口路径 | **可留空**。留空时按路由方式自动拼接；Base URL 已带版本段（`/v1`、`/v3`…）会正确接在版本段后面。特殊网关（如 Azure、自建代理）可手填 `/chat/completions` 或完整 URL |
| 系统提示 | 可留空，默认用群聊成员人设 |

管理操作：

- **取消模型选择**：成员卡片上把「参与全体」取消勾选，发「全体」时不再叫它（仍可单独定向）。内置的 Claude / Codex / CodeBuddy 同样是这个开关。
- **移除模型**：自定义成员卡片上的「移除」按钮，删配置 + 历史。
- 自定义模型有独立的多轮历史（存在 `hub.db` 的 `api_history` 表），「重置会话」清空它。

## 排队、预算与上下文上限

一次发送里的每个成员都是一个**排队任务**（`turn_queue` 表），不再直接起线程：

- 同一成员永远只跑一轮；全局并发由 `queue.max_parallel` 控制（默认 2），多出来的排队，不占线程。
- `GET /api/queue` 看排队与运行中的任务；`POST /api/queue/cancel {"id": 12}` 取消其中一条（排队中直接作废，运行中走正常中断）。终端版对应 `/queue` 与 `/cancel 12`。
- 进程重启时，遗留的排队任务一律标失败并广播原因，**不会自动补跑** —— 自动补跑会把同一句话答两遍。
- 预算：`budget.max_tokens` / `budget.max_turns`（0 = 不限）。超限的任务标 `blocked` 并写明原因，根本不进模型。
- 熔断：某成员连续失败 `queue.fail_streak` 次后冷却 `queue.cooldown_sec` 秒，期间 `@all` 会跳过它。
- 上下文：`context.max_tokens` 按估算 token（中文 1 字≈1、英文 4 字符≈1）从最前面淘汰历史；被淘汰的消息压成一行一条的确定性摘要，并写进 `compactions` 表，便于事后判断「压缩后为什么变笨」。

## 任务、运行表与重放

- 每个成员的每轮执行都是一条**任务**（状态机取 A2A 子集：submitted / working / input-required / completed / failed / cancelled）；接力产生的子任务带 `parent_task_id`，完成必须带 `closure_reason`。
- `GET /api/tasks?status=open` 看进行中的任务；`GET /api/runs?limit=50` 是运行表（轮次左连任务，带 token 消耗）；终端版 `/tasks`、`/runs`。
- `POST /api/replay {"message_id":N}` 重放：回复类消息重跑给它的 sender，用户消息重跑给原 target（终端版 `/replay N`）。

## MCP Server（把中枢开放给你的 Agent）

`POST /mcp` 提供无状态 JSON-RPC（一次请求一次响应），鉴权与 /api 相同（`X-ClaudeLink-Token` 头）。工具：`list_agents`、`send_message`、`read_inbox`、`get_history`、`list_tasks`、`set_context`。接入示例：

    claude mcp add --transport http claudelink http://127.0.0.1:8787/mcp --header "X-ClaudeLink-Token: $(cat hub.token)"

## OTel 实测用量（可选）

`POST /v1/traces` 接收 **OTLP/HTTP JSON**，把带 `gen_ai.usage.*` 属性的 span 存进 `otel_usage`；`GET /api/otel` 按成员看近 24h 实测 token。这目前只是观测数据（turns 的四桶口径不变）。成员侧以 Claude Code 为例，在 settings 的 env 里设 `CLAUDE_CODE_ENABLE_TELEMETRY=1`、`OTEL_EXPORTER_OTLP_PROTOCOL=http/json`、`OTEL_EXPORTER_OTLP_ENDPOINT=http://127.0.0.1:8787`、`OTEL_EXPORTER_OTLP_HEADERS` 带 token。

## 配置：全部集中在 `config.json`

所有可调参数都在这一个文件里。窗口里的操作（成员面板的「流式」「单次最大输出」「准入授权」）会**写回该文件**并立即生效；
手工编辑文件后，点顶部「重新加载数据」或重启中枢生效。程序化读写：`GET /api/config`、`POST /api/config`（传 `{"config": {...}}` 做深合并）。

| 段 | 键 | 默认 | 作用 |
| --- | --- | --- | --- |
| `server` | `host` / `port` | `127.0.0.1` / `8787` | 监听地址与端口 |
| `server` | `auth` | `true` | 本地 API 是否要求 token；`false` 只关 token，Host/Origin 仍校验 |
| `workspace` | `cwd` | 留空 = 中枢所在目录 | 各成员的工作目录（不存在会自动创建） |
| `context` | `history_limit` | `40` | 群聊记录注入多少条；**重锚时**取值，两次重锚之间只追加（见「缓存命中」）。`0`=不限 |
| `context` | `memory_mode` | `hub` | `hub`=窗口掌管上下文（删改立即影响模型）；`native`=CLI 自己的会话 |
| `context` | `shared_context` | `""` | 公告板初值（窗口里保存公告也写这里） |
| `context` | `cache_prefix.enabled` | `true` | 按会话冻结 prompt 前缀让缓存命中（见「缓存命中」）；关掉退回每轮重拼 |
| `context` | `cache_prefix.reanchor_chars` | `160000` | 前缀超过这么多字就重锚一次（那轮付一次未命中）；`0`=永不重锚（prompt 无上限增长） |
| `context` | `cache_prefix.cold_start_minutes` | `10` | 界面上「本轮可能冷启动」的**时间**阈值（分钟）；`0`=只用会话变更判据。成员级可覆盖：`agents.<名>.cache_ttl_min`（见「冷启动提示」） |
| `limits` | `turn_timeout_sec` | `420` | 单轮超时（秒）；**填 `0` = 无上限**（永不因超时被杀） |
| `limits` | `max_output_chars` | `0` | 全局「单次最大输出」上限（字符）；`0` = 无上限，会被成员级覆盖 |
| `streaming` | `enabled` | `true` | 总开关；关掉后所有成员都不流式 |
| `streaming` | `min_chars` / `min_interval_ms` | `8` / `80` | 增量广播节流：新增≥N字或距上次≥N毫秒才推一次 |
| `relay` | `enabled` / `max_depth` / `max_fanout` | `true` / `2` / `4` | @点名自动接力开关、最大层数、单次最多扇出人数；`max_depth=0` = 无上限（不推荐） |
| `claudelink` | `mirror` | `true` | 是否把 `~/.claudelink/nexus.db` 的 MCP 消息投到窗口 |
| `permissions` | `mode` | `workspace-write` | `read-only` / `workspace-write` / `danger`；成员级可覆盖 `agents.<名>.permissions.mode` |
| `permissions` | `default` | `unrestricted` | **旧键**，只做迁移：`unrestricted`→`danger`、`workspace`→`workspace-write`；新配置请用 `mode` |
| `permissions` | `grants.<成员>` | 见文件 | **准入白名单**：`[{ "path": "...", "mode": "rw\|ro" }]`，窗口里加/删授权会同步到这里 |
| `ui` | `activity_bar` | 见文件 | 左侧活动栏的项与图标（图标名或内联 `<svg>`） |
| `agents.<名>` | `enabled` / `label` | — | 是否参与全体、显示名 |
| `agents.<名>` | `stream` | `true` | 该成员是否流式输出 |
| `agents.<名>` | `max_output_chars` | `0` | 该成员的「单次最大输出」（0=用全局） |
| `agents.claude` | `exe` / `settings_profile` / `settings_dir` | `%CLAUDELINK_*%` | `claude` 可执行文件与 `~/.ccm/settings` 里的模型档案（**都是环境变量占位符**，见上文「成员 CLI 的路径」） |
| `agents.codex` | `sandbox` | `danger-full-access` | **旧键**：仅在 `permissions.mode` 缺省时作为 fallback；新配置请用 `permissions.mode` |
| `agents.codebuddy` | `exe` / `node` / `max_turns` | `%CLAUDELINK_*%` | CodeBuddy CLI 路径、node、可选轮数上限 |
| `agents.<名>` | `usage_input_includes_cache` | 见文件 | **该端点的 `input` 含不含缓存命中**（逐端点，不是逐协议）；配错命中率会差一倍。见「缓存命中 → 口径」 |
| `agents.dsh` | `exe` / `node` / `profile` | `%CLAUDELINK_*%` / `headless` | DeepSeek Harness；`profile` 决定 boot 哪个 dsh profile |
| `agents.dsh` | `supports_native_memory` / `model_capable` | `false` / `false` | 该 CLI 无法续接会话、也不接收模型参数 → 界面上隐藏对应控件（见「DeepSeek Harness」一节） |
| `model_overrides.<模型id>` | `stream` / `max_output_chars` | — | 自定义 API 模型的同名覆盖项（由成员面板写入） |

**没放进这个文件的**：自定义模型的凭据（`base_url` / `api_key` / 模型名 / `max_tokens`）存在 `hub.db` 的 `models` 表，由「＋ 添加模型」对话框管理——避免把 key 混进日常要编辑的配置文件。

### 无上限（`0`）一览

所有数值型上限统一约定：**填 `0` = 无上限**。成员面板里的「单次最大输出」有下拉选项「无上限 / 限字」，选无上限时按钮变灰、直接写 0。

| 参数 | 0 的含义 | 风险 |
| --- | --- | --- |
| `limits.max_output_chars`、`agents.<名>.max_output_chars`、`model_overrides.<id>.max_output_chars` | 不截断正文 | 超长回复会撑大上下文与界面 |
| `limits.turn_timeout_sec` | 永不因超时杀进程 | 卡死的 CLI 会一直挂着，需手动「中断本轮」 |
| `relay.max_depth` | 接力不限层数 | 成员互相 @ 可能停不下来，建议保持 2～3 |

### 单次最大输出的实际语义

| 通道 | 实现 | 说明 |
| --- | --- | --- |
| 自定义 API 模型 | 请求体里的 `max_tokens` | 模型侧真实生效；模型中转站也可能再截 |
| Claude / CodeBuddy / Codex | 中枢侧截断 `max_output_chars` | CLI 没有可靠的输出上限开关（实测 Codex 的 `model_max_output_tokens` 被判为未知键、Claude 的 `CLAUDE_CODE_MAX_OUTPUT_TOKENS` 被忽略），所以由中枢在收到完整回复后按字数截断并标注 |

### 为什么会出现「返回为空」

带思考（reasoning）的模型会把 `max_tokens` 先花在 `thinking_delta` 上；预算被思考吃满时，整条流里**一个 `text_delta` 都没有**，早期版本就把它判成"返回为空"。

现在四类通道都会把思考内容单独累积：

- 正文为空但思考非空 → 直接把思考内容回给你，并在开头标注"本轮只输出了思考内容，通常是单次最大输出被思考占满"；
- 正文与思考都为空 → 报错里带上 `stop_reason`（例如 `max_tokens`），一眼能看出是被截断还是接口异常。

经验值：带思考的模型（DeepSeek 这类）`max_tokens` 至少给 **4096**；添加模型对话框的默认值已从 1024 改成 4096。

## 成员是怎么被驱动的

每个成员都以「无交互」方式被调用（`-p` 之类的单轮模式），不需要终端窗口；
勾了「原生记忆」的成员另外带一个会话 id，从而能续接 CLI 自己的会话：

| 成员 | 调用方式 | 会话续接 |
| --- | --- | --- |
| Claude | `claude --settings <ccm profile> -p --output-format stream-json --permission-mode <mode>` | `--resume <session_id>` |
| Codex | `codex app-server` JSON-RPC：`thread/start` + `turn/start`（`sandboxPolicy` 按 mode） | thread id（`thread/resume`） |
| CodeBuddy | `node <codebuddy-code cli> -p --output-format stream-json --permission-mode <mode> --tools ...` | `--resume <session_id>` |
| DeepSeek Harness | `node <dsh> --profile headless "<任务>"` | 无（每次新会话） |

### DeepSeek Harness（`dsh`）

`dsh` 走 `--profile headless`：跑一次性任务、把最终回答打到 stdout 后退出。它有三条硬限制，
都是 headless profile 自己的（见 `dsh-headless/lib/index.js`），不是中枢少做了什么：

| 限制 | 后果 | 中枢怎么办 |
| --- | --- | --- |
| 任务官方只从**命令行参数**来，不收 stdin | Windows 命令行上限约 32KB，而群里带历史的 prompt 常年 4 万字以上 | **走环境变量**（见下） |
| **没有 `--resume`**，每次都新建会话 | 不可能有原生记忆 | `supports_native_memory: false`，面板里不显示「原生记忆」勾选框，它只用窗口记忆 |
| **没有任何 app 参数**（`--help` 只有 `-h`） | 外部指定不了模型 | `model_capable: false`，面板里不显示模型输入框；模型由 `~/.dsh/settings.yaml` 的 `agent-default-model` 决定 |

#### 超长 prompt 怎么送进去

headless 的 `task` 只能走 argv，所以中枢把整条任务塞进 **`DSH_TASK` 环境变量**，
命令行上只留一个短占位 —— 环境块没有那个 32KB 限制（实测 25 万字仍正常），
既不落盘、也不用模型多读一次文件。这需要 profile 接一下线，已经加好了：

`~/.dsh/profiles/headless/cordis.patch.yml`

```yaml
- id: headless-runner
  config:
    task: !!js process.env.DSH_TASK || ctx.headlessStartup.task
```

没有 `DSH_TASK` 时行为不变（照旧用命令行里的 task），所以手敲
`dsh --profile headless "任务"` 不受影响。改完 `~/.dsh/profiles/*/cordis.patch.yml`
不用重启中枢，下一轮就生效。

**接线丢了会怎样**：中枢每轮检查这个 profile 有没有接上；没接上就退回
「把 prompt 落到 `workspace.cwd` 下、让 dsh 先读它再作答」（用完即删，但每轮多一次读文件的工具调用）。
退回时只在中枢控制台打印一次说明 + 群里发一次提示，不会每轮刷屏。

输出是纯文本（不是 JSON 事件流），所以中枢会滤掉自己注入的心跳行（`[仍在执行] 已运行 N 秒…` 等），
避免把它们拼进回复里。要手动试：`node "<dsh路径>" --profile headless "只回复 OK"`。

历史消息存在 `hub.db`（SQLite），会话 id 存在同一库的 `sessions` 表；删掉 `hub.db` 即完全重置。

## 排错

- 窗口打不开：确认 `ClaudeLink Hub` 控制台还在，且 `hub.out.log` 无异常。
- 某一方一直不回复：先单发一条「只回复 OK」看是不是该 CLI 自身的问题；Claude 侧报 `WinError 2` 说明命令没解析到真实 exe（`hub.py` 的 `resolve_command` 负责这个）。
- 端口被占：改 `config.json` 的 `port`。
- 命中率一直是 0 或 `—`：
  - `—` 表示**本会话还没有可统计的用量**（分界时刻之后一轮都没跑）；跑一轮就有数字。
  - 该成员是不是勾了「原生记忆」？那它的用量大头在 CLI 自己的会话里，命中率由 CLI 决定（见「缓存命中」末节）。
  - 该成员是不是 `dsh`？它不报用量，永远显示「该 CLI 不报用量」。
  - 每轮都在重锚？（改写/删除消息、改高亮、改权限、换模型都会触发重锚）
    看 `SELECT prefix_chars, anchor_msg_id FROM prompt_cache WHERE conv_id=<会话号>` 是否在变。

## 维护与目录

源码运维见 [运维手册](ops.md)，工作区分类见 [目录导航](../目录导航.md)。历史交接和旧运维在 [docs/history](history/README.md)，验收报告在 [docs/reports](reports/README.md)；这些内部资料不随 npm 包发布。
