# 0.5.0：更名 Chorum、直连 API 模型的工具调用修复

0.4.0 把界面和实例管理补齐了，但**命令行**这条路仍有两个缺口：一是「不装任何 CLI 也能用」这件事只能开网页完成；二是直连 API 模型的工具调用在若干具体条件下会失败或看起来卡死。本版修复这些已复现的问题，并把产品从 `claudelink-hub` 更名为 **Chorum**（npm 包名 `chorum`），终端入口同名为 `chorum`。

## 已复现并修复

| 问题 | 原因与修复 |
| --- | --- |
| 工作目录指向已不存在的路径，成员在空气目录里干活 | `workspace.cwd` 停在迁移前的 `D:\AI-GroupChat`（项目已在 `F:`）。旧代码在 `main()` 里无条件 `os.makedirs(DEFAULT_CWD)`，把这个不存在的目录**默默建出来**，随后所有 CLI 成员与 API 模型的工具根都落在那里。现在启动时校验：存在就用，不存在就回退到数据目录，并在启动日志与群聊里各说一次；`doctor` 增加「工作目录」一行，失效直接标 ✗。 |
| 工具调用在过去能跑，但在某些工作区里 100% 失败 | `ToolRuntime._path` 检查的是**绝对路径的每一个分量**，只要工作区路径里含点目录（`<repo>/.workbuddy/…`、`~/.config/…`），每次 `read_file` / `list_files` 都被判成 “path outside granted roots”。现在只检查**授权根之下**的分量，根自身是用户给的，不再被点号规则误伤。 |
| 工具步数跑到上限时整轮以 400 结束 | 末步用 `tool_choice:"none"` 收口，但这是 OpenAI 的形状；Anthropic 只接受对象。现在末步**直接不提供 `tools`**（两家都接受），模型只能给正文，本轮必定收口。 |
| 多步工具调用期间界面一个字都没有，像卡死 | 工具循环只把**最终**正文发给 `on_text`，调工具之前的说明文字被丢掉。现在每步的正文都会实时发出（含 Anthropic 的 preamble）。 |
| 工具参数不是合法 JSON 时整个循环崩掉 | 解析失败现在转成一次「参数非法」的工具结果回灌给模型，循环继续，而不是抛异常终止整轮。 |
| 一次回复里工具调用超过 16 个仍会先执行 16 个再报错 | 改为**先判定再执行**，不产生副作用。 |
| 升级 npm 包后每次命令都重启中枢，正在跑的轮次被打断 | `package.json` 版本与 `hub.py` 的 `APP_VERSION` 各写一遍，漏改一个就出现「CLI 认为是旧版本 → stop → start」。现在 `APP_VERSION` 从 `package.json` 读，单一来源。 |
| 终端版启动器写死机器路径，项目一搬迁就「打不开」 | `tools/mcp-tui/tui-launch.js` 把「迁移前的旧项目目录」与「某个 conda 环境里的 python.exe」写成了兜底常量。现在按「环境变量 → `~/.claudelink/hub.json` → 启动器上溯 → 同级安装包 → npm 全局根 → 当前目录上溯」逐层解析，失败时打印**每一层试过的路径**；Python 也改为真实探测（≥3.9 且带 sqlite3），避免 Windows Store 存根。 |
| 命令行无法添加/驱动 API 模型 | 新增 `chorum model list/add/test/rm` 与 `chorum ask --to <id|名称>`：添加模型、发一条消息、把模型发起的工具调用逐步打在屏幕上，回复走 stdout、进度走 stderr（可管道）。没有 CLI 成员时命令行不再只能提示「去网页点」。 |
| 工作台视图切换按钮点击后属性值被引号截断 | `safe()` 走 `textContent→innerHTML` 时**不转义引号**，直接拼进 `value="…"` / `data-*="…"` 会被截断。新增 `attr()` 用于属性上下文。 |

## 命名

- 包名 `claudelink-hub` → **`chorum`**，命令 `chorum`。
- 注册四个 bin：`chorum`（主）、`chorum-hub`、`claudelink-hub`、`claude-hub`。旧的 `claudelink-hub@0.4.0` 已从全局卸载（它的数据目录备份在 `~/.claudelink/backup-claudelink-hub-20261115/`），因此四个名字可以一起用，不再有 shim 冲突。
- **协议与环境变量不改**：`X-ClaudeLink-Token`、`CLAUDELINK_*`、`~/.claudelink/` 保持不变 —— 改这些要连带迁移已装的包、配置与数据目录，风险大且没有功能收益。
- 上游 npm 包 `claudelink@1.4.3`（MCP 服务端）与此无关，仍是可选依赖；终端版启动器对 `chorum`、`chorum-hub`、`claudelink-hub` 都认。

## 验收

```bash
npm run e2e:model   # mock provider ⇄ 中枢 ⇄ CLI：两种协议各跑一次带工具调用的完整回合
npm run test        # 既有回归（Python 侧 17 项 + Node 侧检测）
npm run selftest    # 注册表 / 检测 / 并发锁
npm run smoke       # 临时目录里的一次真实安装运行
npm run pkg-e2e     # npm pack → 临时 prefix 安装 → doctor
```

`e2e:model` 断言的是：正文进 stdout、工具步骤进 stderr、provider 收到两次请求且首次带 `tools`、工具结果真的回灌给模型。它证明**链路可以发起并完成调用**，不证明真实模型的话题质量。

## 仍未覆盖

- 直连 API 模型在**带工具**时走的是非流式请求（逐字流式只在无工具路径上）；界面能看到每步正文与工具行，但看不到逐字打字机效果。
- 真实模型的长会话成本、并发压力、以及不同中转站对 `tools` 字段的兼容性，不在自动化通过结论里。
