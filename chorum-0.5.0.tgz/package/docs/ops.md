# 运维手册

适用版本：**Chorum 0.5.0**（原 ClaudeLink Hub，包名 `chorum`，命令 `chorum`）。更新日期：2026-11-15。

本文件是当前日常运维入口。整理前原文完整保存在 [历史运维手册](history/运维-整理前-20261028.md)，旧交接和诊断记录集中在 [历史资料](history/README.md)，不再作为当前状态说明。

## 0.5.0 新增的命令入口

| 命令 | 用途 |
| --- | --- |
| `chorum model add/list/test/rm` | 直接配置 API 模型，不必开网页 |
| `chorum ask --to <id\|名称> "…"` | 发一条消息并实时显示回复与它的工具调用（`--timeout` / `--no-wait` / 结尾 `-` 读 stdin） |
| `chorum status` | 看当前实例：地址、版本、成员、是否忙（不启动、不写盘） |

`doctor` 增加「工作目录」一行：`workspace.cwd` 指向不存在的路径时会直接标 ✗，并说明中枢会回退到数据目录。

## 1. 启动、停止与正确入口

在工作区根目录执行：

```powershell
npm run tui
npm run web
npm start
npm run doctor
```

| 入口 | 当前行为 |
| --- | --- |
| `npm run tui` / `claudelink-hub tui` | 打开终端工作台；需要时启动中枢 |
| `npm run web` / `claudelink-hub ui` | 启动或复用中枢并打开 Web 工作台 |
| `npm start` / `claudelink-hub start` | 前台运行中枢并打开网页；`--detach` 使用后台模式 |
| `claudelink-hub stop` | 经鉴权停止中枢；可中断执行中任务；数据保留 |
| `npm run harness` | 运行旧 PEACOCK 配置导出页，默认 5173；不是多智能体中枢 |

中枢默认地址为 `http://127.0.0.1:8787`。旧 PEACOCK 位于 `legacy/peacock/`。

关闭 TUI 只关闭终端客户端，中枢和圆桌可能继续执行。暂停圆桌使用 `/round stop`；停止全部轮次使用 `/stop`；结束整个中枢使用 `claudelink-hub stop`。

`start / tui / ui / stop` 统一解析运行实例、数据目录、版本和代码摘要。空闲旧服务可使用原数据重启；检测到执行中、排队、圆桌或工作流任务时拒绝自动升级。不要把多个启动器同时拉起或按历史文档中的固定 PID 杀进程。

## 2. 当前数据目录与配置来源

本机已确认的数据目录是工作区中的 `claudelink-hub/`；全局 npm 安装的程序可使用这份原配置和数据库。运行路径与数据路径允许不同。

| 文件 / 目录 | 作用 |
| --- | --- |
| `config.json` | 服务端口、成员、默认限制、权限、工具等配置；可能含敏感端点或凭据 |
| `hub.db`、`hub.db-wal`、`hub.db-shm` | 聊天、轮次、步骤、权限、模型、任务、队列、持久检查点 |
| `memory.db` 及 WAL/SHM | 独立的短期 / 长期记忆 |
| `hub.token` | 本机 HTTP / MCP 鉴权凭据，不打印、不分享 |
| `roundtable.json` | TUI 上次圆桌配置，不等同于运行中的圆桌状态 |
| `uploads/` | 附件与解析文本关联文件 |
| `hub.log` | 后台或自动启动的服务输出 |
| `hub.errors.log` | 成员调用异常现场；分析时按时间区分历史错误 |
| `hub.pids.json` | 进程跟踪状态，不是可跨机器恢复的业务数据 |
| `logs/` | 现有会话镜像与镜像进程状态，位置保持不变 |

位置覆盖：`CLAUDELINK_HOME` 指定数据目录，`CLAUDELINK_CONFIG` / `--config` 指定配置；未显式指定时，npm 安装版优先使用已确认的默认实例元数据，再按安装方式选择目录。全新安装可落在 `~/.claudelink-hub`，已有包目录数据仍兼容。不要假定所有机器的数据都在安装目录或用户目录。

本机实例元数据在 `~/.claudelink/instances/`；`default.json` 保留默认数据 / 配置路径，不包含 token 正文。自定义元数据位置可用 `CLAUDELINK_RUNTIME_DIR`。

用户 Agent 注册表 `~/.claudelink/agents.json` 与检测缓存 `~/.claudelink/agents.detected.json` 不同；不要拿检测输出覆盖用户注册表。`~/.claudelink/nexus.db` 是另一个 ClaudeLink 消息库，不是本项目的 hub.db。

## 3. 成员状态与实际调用

“参与全体”目前同时是成员启用开关。未勾选的成员不能被单独调度；它的灰色圆点表示停用，不是远端连接探针的结果。

调用流程：在 Web 左侧“成员与模型”勾选成员的“参与全体”，再从底部选择接收方并发送。TUI 启用成员后可用 Tab 或左右键切换目标，Enter 发送。

Codex 与 DeepSeek Harness 的启用值以当前 `/api/state` 为准；旧截图、旧错误卡与历史交接不能代替实时状态。本轮整理不修改成员启用值。

| 状态 / 证据 | 能说明什么 |
| --- | --- |
| CLI 文件存在、`--version` 成功 | 可执行程序探针通过；尚不能证明登录、额度或模型可访问 |
| 成员已启用、当前空闲 | 可以参与下一次调度，不代表存在常驻 CLI 会话 |
| 执行中 | 中枢正在运行该成员的回合 |
| 出现旧错误卡片 | 对应历史回合失败，需结合时间和当前版本判断 |
| 真实回合成功 | 该次输入、账号、模型、网络路径下调用通过 |

Codex 默认使用本机 `exec --json`，原生记忆使用 `exec resume`，继承本机登录与配置。DeepSeek Harness 使用自己的 headless profile；当前适配器不支持原生会话续接，`native_memory_capable=false` 与是否启用是两回事。

## 4. 终端与 Web 操作

| 操作 | TUI |
| --- | --- |
| 协作操作菜单 / 圆桌入口 | F1；也可 `/round` |
| 模型目录或自由输入模型 ID | F2；也可 `/model <成员> <模型>` |
| 推理强度 | F3；也可 `/effort <成员> <值>`；`auto` 跟随默认 |
| 工具参数、输出和失败 | F4 / `/tools` |
| 可见推理摘要全文回看 | F5 / `/view thinking` |
| 主代理一次调度、执行代理续跑 | F6 / `/work start <主代理> <原始目标>` |
| 短期 / 长期记忆 | F7；F1 可保存；`/memory` 检索 |
| 切换工作区视图 / 翻页 | Ctrl+O；PgUp/PgDn 或滚轮 |

宽终端显示成员、模型、effort 侧栏；窄终端保留菜单。模型和 effort 在回合执行中不可切换，避免旧会话写回。服务商可能拒绝具体模型不支持的 effort 档位，错误应明确展示。

Web 顶部提供讨论、工具记录、推理摘要、持续执行和记忆视图，以及圆桌和执行任务表单。成员设置中的 effort 与 TUI 使用同一接口。只展示服务商实际返回的推理内容，不恢复隐藏思维链。

## 5. 两种协作与重启边界

圆桌：固定角色、顺序和轮数，每回合锚定原议题；`/round again` 载入上次配置；`/round stop` 暂停；`/round resume` 从未完成位置继续。圆桌运行状态在内存，服务重启后不会自动恢复原桌；`roundtable.json` 只是可再次载入的配置。

持续执行：主代理只生成一次 JSON 计划，执行代理按依赖返回 `done / continue / blocked`。默认每个子任务最多 4 步；达到上限、失败或阻塞不算完成。计划和检查点持久化在 hub.db，重启转为暂停，恢复跳过已完成任务。计划尚未保存就中断时，不隐式再次调用主代理。

```text
/work status
/work stop <任务id>
/work resume <任务id>
```

记忆：短期按工作区和会话隔离，长期在同工作区复用。执行代理可自动写带来源的短期检查点；长期记忆由用户显式保存。清空会话会清短期记忆，长期记忆单独管理。

## 6. 体检与只读状态查询

```powershell
claudelink-hub doctor
claudelink-hub doctor --json
claudelink-hub detect
claudelink-hub detect --explain codex
claudelink-hub tui --check
claudelink-hub tui --render-once --no-start
```

`--check` 包含鉴权验证。只看 `/api/health` 200 不足以证明 TUI 能读取会话，也不足以证明 Web 脚本和按钮正常。

以下示例只读取本机版本和成员状态；不要输出 `$serviceToken`：

```powershell
$runtimeDir = Join-Path (Get-Location) 'claudelink-hub'
$serviceToken = [IO.File]::ReadAllText((Join-Path $runtimeDir 'hub.token')).Trim()
$headers = @{ 'X-ClaudeLink-Token' = $serviceToken }
Invoke-RestMethod 'http://127.0.0.1:8787/api/health' | Select-Object version,code_revision,pid,messages
$snapshot = Invoke-RestMethod 'http://127.0.0.1:8787/api/state' -Headers $headers
$snapshot.agents | Select-Object name,enabled,model,effort,running_since
```

默认端口变化时同步更改地址。`CLAUDELINK_TOKEN` 的显式凭据优先，错误时不会被其他文件凭据悄悄替换。

## 7. 备份、升级与迁移

**升级前备份**，不要等 npm 替换旧安装目录后再找配置。

1. 核对实际数据目录、运行版本与在途任务。需要暂停时先保存任务检查点。
2. 使用 `claudelink-hub stop` 正常停止服务后，备份 config.json、hub.db、memory.db、hub.token、roundtable.json、uploads/ 和所需日志。
3. 服务运行时不要只复制单个 `.db`。在线备份使用 SQLite backup API；WAL 数据库不能把 `.db` 与旁文件随意拆开移动。
4. 如果旧 npm 包目录里还有另一份运行数据，也单独备份；不要直接覆盖或合并两个消息库。
5. 从本地包安装，再核对版本、文件清单、鉴权、真实界面和旧数据。

当前没有发布 npm 公共仓库。工作区安装包位于 `.verify/dist/`：

```powershell
npm i -g '.\.verify\dist\claudelink-hub-0.4.0.tgz'
claudelink-hub doctor
claudelink-hub start --no-setup --detach
```

`npm i -g claudelink-hub` 会请求公共仓库，未发布时返回 E404。现有源码与 npm 安装目录分开，更新源码不等于全局安装已更新。更改后端代码需重新加载服务；更改 TUI 需重开客户端；启动器会核对服务版本和代码摘要。

本次整理没有迁移运行数据。此前 0.4 升级前的备份现位于工作区 `archive/verification/backups/runtime-backup-0.4/`；原数据仍在原位置。备份与日志可能含研究材料或凭据，不能整体外发。

## 8. Token、缓存与工具

新配置有历史条数、字符预算、工具步数和任务步数限制；原有显式配置沿用。不要为了省上下文删除原始消息或伪造压缩结果。

缓存比例仅来自服务商实际报告的 cache 用量；未报告应显示“未报告”，不能当作 0%，本地前缀复用也不能当成服务商命中或真实账单节省。

API 成员通过独立工具层读取授权文件、搜索、网页、记忆；CLI 成员使用各自原生工具。网页 403、无结果、超时均需保留为工具失败。Bing RSS 无 key 搜索可用但召回可能偏宽；工具连通不等于材料相关或内容已核查。

## 9. 修改后的验收

在 `claudelink-hub/` 执行：

```powershell
npm test
npm run selftest
npm run test:lifecycle
npm run smoke
npm run pkg-e2e
npm run check
```

`npm run test:browser` 需要现有 Playwright 与浏览器，可设置 `CLAUDELINK_PLAYWRIGHT_MODULE`、`CLAUDELINK_BROWSER`、`CLAUDELINK_PYTHON`。运行时没有新增第三方依赖。

浏览器测试必须包含页面真正执行后的脚本错误、发送与 SSE、模型/effort、工具输入输出、记忆和任务操作。截图中的确定性测试代理不算真实模型连接或科学结论验收。终端应覆盖实际键盘菜单和当前服务版本，不能只测 `--help`。

本次目录整理只需验证移动完整性、引用、旧页面入口、发布白名单和运行中的正式服务；无需为文档变动重新调用模型。

## 10. 常见故障

| 现象 | 核对点 |
| --- | --- |
| npm E404 | 是否误按公共包名安装；使用已有本地 tgz |
| HTTP 401 | TUI、配置、token 是否来自同一运行实例；显式环境凭据是否过期 |
| 网页一直连接中 / 所有按钮无效 | 查看浏览器脚本错误；0.3.x 曾因 token 双重引号导致整段脚本未执行 |
| 更新后仍是旧界面 | 核对全局安装版本、实际服务版本/代码摘要、当前 TUI 进程；不要只看源码文件 |
| 灰点或看不到可调度目标 | 先核对 enabled；“参与全体”当前兼作启用开关，不是远端在线检测 |
| Codex 旧的 app-server 超时 | 核对错误时间与实际 runner；0.4 默认 exec，旧错误卡不代表新路径已失败 |
| DeepSeek Harness 没有原生记忆 | 当前适配器不支持续接，不能据此判断离线 |
| 自动升级拒绝重启 | 存在执行中、排队、圆桌或工作流任务；保留任务后再处理 |
| 模型设置被拒绝 | 该成员仍在执行，或模型不支持该参数 |
| 模型没有回应 | 逐回合查错误、工具结果、认证与额度；CLI 探针通过不是连接成功 |

## 11. 整理后的目录与历史资料

工作区总索引：[目录导航](../目录导航.md)。逐项旧新路径与 SHA256：[本次移动清单](../.verify/organization-20261028/move-plan.json)。

- 产品运行代码：当前目录的 Python 模块、`bin/`、`web/`。
- 产品测试：`scripts/`、`test/`；维护诊断：`tools/`。
- 当前设计、接入和升级文档：`docs/`；验证报告：`docs/reports/`；原运维/交接：`docs/history/`。
- 配置与代码快照：`backup/config-snapshots/`、`backup/code-snapshots/`；原始 trace：`backup/trace-captures/`。
- 根目录旧验证材料：工作区 `archive/verification/`，按脚本、报告、日志、浏览器证据、预览、备份和测试数据分类。
- 旧 PEACOCK：工作区 `legacy/peacock/`。
- MASCOT 研究材料与 B128 分析：工作区 `references/mascot-audit/`，不作为中枢产品代码。
- 同类项目：工作区 `同类的项目/`，内部结构未改动。

历史报告中的 PID、旧路径、版本和旧验收结果只代表记录时点。归档脚本保留原文；其中依赖原始路径、外部数据或已移除环境的脚本不视作当前可运行入口。检索旧文件先查移动清单。
