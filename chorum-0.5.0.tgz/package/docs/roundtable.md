# 终端圆桌模式：多 CLI × 角色 × 固定轮数

> 入口：`python hub_tui.py` → `/round`。本文记录实现取舍与文献依据。

## 1. 它是什么

用户按顺序选若干 CLI 实例，为每个实例指定：

- 角色名（如「架构师」「评审」「实现者」）；
- 系统提示词（角色边界、关注点、输出要求）；
- 发言顺序（输入顺序即顺序，不是 `dispatch.order`）；
- 轮数（默认 2，硬上限 20）。

**同一个 Agent 可以出现多次**（例如两个 CodeBuddy）：每个出现是一个独立实例，用唯一 slot 标识（`codebuddy`、`codebuddy#2`）。slot 决定运行时身份（锁、原生 `--resume` 会话、子进程、取消标志），真正的 runner/配置仍用 base agent。这样两个 CodeBuddy 各有自己的 CLI 会话和角色提示，不会共享内部记忆。

注意：如果成员用的是中枢记忆（`memory_mode=hub`，默认），每轮本来就是无状态 CLI 调用，不存在跨调用会话；如果勾了「原生记忆」，slot 才会把各自的 `--resume` 会话 id 分开存。

然后中枢按 `第 1 轮 → 成员 A → B → C → 第 2 轮 → A → B → C` 跑完，期间不接受 `@` 接力、不参与 `parallel/auto` 调度。

## 2. 为什么是「固定顺序 + 固定轮数」

| 选择 | 依据 | 取舍 |
| --- | --- | --- |
| 固定顺序（round-robin） | AutoGen `GroupChat` 的 `round_robin` 是最可预测的选择；LLM 选下一位（`auto`）更灵活但更贵、更容易卡住 | 放弃动态调度，换来可复现、可中断、成本可估 |
| 固定轮数 | AutoGen `max_round`、CAMEL 的终止条件都强调硬上限 | 不做「无限讨论」；需要更多轮就重开 |
| 每角色独立提示 | CAMEL 的 inception prompting、MetaGPT 的 SOP、ChatDev 的 chat chain 都把角色规格写进提示 | 角色越具体越不容易串戏；但提示词由用户负责 |
| 同 Agent 多实例 | AutoGen 强制成员名唯一；SPP（NAACL 2024）证明单模型多 persona 自协作有效；Inner Committee 模式提醒同一模型仍有相同盲点 | 每个实例独立 slot + 独立 CLI 会话；别指望多开同一模型自动产生真正多样性 |
| 共享会话记录 | ChatDev 在同一阶段内让角色看到完整对话；Du et al. 的辩论也是每轮看到他人答案再修正 | 后发言者能看到前文；长会话会触发 `history_limit` 截断 |
| 禁止 @ 接力 | 圆桌顺序由主持人固定；接力会把顺序打乱 | 独立于 `relay`，不改全局开关 |

## 3. 执行流程（`hub.py`）

1. `POST /api/roundtable/start` 校验：≥2 个实例、每个实例的 base agent 启用、slot 不重复、轮数 1–20、系统提示 ≤12000 字。
2. 默认 `new_conversation=true`：新建「圆桌 · 议题」会话并切过去；会话成员记录唯一的 base agent 集合。
3. `_run_roundtable` 逐轮逐位调用 `_run_agent`：
   - `trigger_kind="roundtable"`，`_run_agent` 结束时不调用 `_maybe_relay`；
   - `conv_id` 钉住开桌时的会话，用户切走会话就收桌；
   - `role_prompt` 进入 `frozen_prompt` 的稳定前缀（同一桌逐字节不变，前缀缓存仍可命中），同时作为 `system_extra` 传给支持真实系统提示的 runner；
   - `slot` 决定 `self.locks` / `self.cancel` / `self.procs` / `self.running` / `sessions` 的键，所以同 Agent 的多个实例互不干扰；
   - `sender_label` 让回复以「CodeBuddy·评审」这样的角色名落库，而不是两个 CodeBuddy 混在一起；
   - `others_override` 只把本桌实例写进「群成员表」，避免角色看到无关成员。
4. 每轮开始广播 `{"type":"roundtable", ...}`；终端据此显示「圆桌 1/2 · 2/4 · 评审（codex）」。
5. 暂停/继续：`/round stop` 或全局 `/stop` 只置位 `rt_stop` 并中断当前 CLI 子进程，不销毁圆桌；`_run_roundtable` 用 `completed` 游标记录已完成到第几位，`/round resume` 从下一位继续。被中断的那一位没有产出回复，resume 会重跑它；已经完成的圆桌再 resume 会自动追加一轮。

### 终端设置页

选完参与成员后**直接进入设置页**（`rt_setup_lines`），默认角色=成员名、提示词为空；需要时再改，不必强制逐项填写：

```
圆桌设置 · 顺序 / 成员 / 角色 / 系统提示词
 1  CodeBuddy       CodeBuddy      （默认）
 2  CodeBuddy #2    评审           你是一名严格的评审…
 3  Codex            Codex          （默认）
轮数 2 · 议题 … · 新开会话
↑/↓ 选择 · e 角色 · p 系统提示词 · a 添加实例 · d 删除 · u/j 移动 · r 轮数 · t 议题 · n 会话 · Enter 开始 · Esc 取消
```

`p` 打开系统提示词编辑时会把当前文本预填进输入框（多行可粘贴），Enter 保存回设置页；`e` 改角色后会顺带进入同一实例的提示词编辑。`a` 可以再添加同一个 Agent，自动分配 `agent#2` 这样的 slot。

## 4. Prompt 结构

```
[角色前言：成员表 + 你是 X]                 ← frozen_prompt 稳定前缀
[圆桌角色设定 · 本会话系统级约束]            ← 用户填的系统提示词
你是「评审」。
<用户提示词>
这是一场固定顺序的圆桌讨论：……禁止 @……
[角色设定结束]
[权限块]
[历史记录]
[本次消息：第 r/R 轮 · 第 i/N 位；议题；发言要求]  ← 易变尾部
```

把角色设定放在稳定前缀，是为了不破坏前缀缓存；把「第几轮/第几位」放在尾部，是因为它每轮都变。

## 5. 已知失败模式与对策

参考 MAST（Multi-Agent System Failure Taxonomy，arXiv:2503.13657）：

| 失败模式 | 本实现的处理 |
| --- | --- |
| 违反角色设定（FM-1.2） | 角色名 + 系统提示 + 「只代表本角色」约束；每轮重复一次 |
| 不知道终止条件（FM-1.5） | 硬轮数 + 随时暂停/继续；界面上显示 `r/R` 与 `completed/total` |
| 步骤重复（FM-1.3） | 提示「每轮在上一轮基础上推进，不复述全文」；后一位能看到前文 |
| 信息不同步 | 共享同一会话历史；`conv_id` 钉住，避免写到别的会话 |
| 上下文爆炸 | 每轮有字数建议（默认 600）；`history_limit` 仍生效 |
| 同模型实例互相附和 / persona drift | 每个实例独立 CLI 会话；角色提示要写具体；默认 2 轮，先用 2–3 个实例验证，不要用「多开同一个模型」代替真正的多样性 |

## 6. 成本

- N 个成员 × R 轮 = N×R 次独立 CLI 调用；每个 CLI 还可能在自己的工具循环里重发上下文（池 B）。
- 本仓实测报告指出：多智能体成本的大头是每个成员自己的轨迹，不是中枢拼的共享窗口；纯讨论场景「单上下文多角色」可以做到 N×→1×，但会失去 CLI 隔离。
- 因此默认 2 轮，建议先用 2–3 个成员验证角色提示，再增加轮数。

## 7. 参考文献

- Wu et al., *AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent Conversation*, arXiv:2308.08155. GroupChat / `round_robin` / `max_round` / custom speaker selection.
- Li et al., *CAMEL: Communicative Agents for “Mind” Exploration of Large Language Model Society*, NeurIPS 2023, arXiv:2303.17760. Inception prompting、角色边界、终止标记。
- Qian et al., *ChatDev: Communicative Agents for Software Development*, ACL 2024, arXiv:2307.07924. Chat chain、阶段顺序、角色对、communicative dehallucination。
- Hong et al., *MetaGPT: Meta Programming for A Multi-Agent Collaborative Framework*, ICLR 2024, arXiv:2308.00352. SOP、角色分工、结构化中间产物。
- Du et al., *Improving Factuality and Reasoning in Language Models through Multiagent Debate*, ICML 2024, arXiv:2305.14325. 多轮提议-批评-修正。
- Liang et al., *Encouraging Divergent Thinking in Large Language Models through Multi-Agent Debate*, EMNLP 2024, arXiv:2305.19118. Judge、自适应终止。
- Cemri et al., *Why Do Multi-Agent LLM Systems Fail?*, arXiv:2503.13657. MAST 失败分类（14 种失败模式，3 大类）。
- Wang et al., *Unleashing the Emergent Cognitive Synergy in Large Language Models: A Task-Solving Agent through Multi-Persona Self-Collaboration*, NAACL 2024. 单模型多 persona 自协作；细粒度 persona 优于固定数量。
- Agent Patterns Catalog, *Inner Committee / Multi-Persona Single Model*. Persona 切换成本、同模型盲点、persona drift；每个 persona 只看角色需要的输入。
- AutoGen GroupChat 的「所有成员必须唯一命名」约束：重复名字会让发言归属/路由歧义，解决方式是给实例加后缀（`worker-0` / `worker-1`）。
- Tran et al., *Multi-Agent Collaboration Mechanisms: A Survey of LLMs*, arXiv:2501.06322. Actors / types / structures / strategies / coordination 分类。

## 8. 刻意没做

- 动态选下一位（LLM 当主持人）：更灵活，但不可预测且多一次调用；需要时可在 `_run_roundtable` 里加。
- 裁判/共识终止：当前是固定轮数；如果要「吵到一致为止」，可以加一个 judge 角色和 `is_termination` 检查。
- 并行发言：固定顺序的目的就是让后一位看见前一位；并行会失去这个性质。
- 角色隔离上下文：Inner Committee 建议每个 persona 只看角色需要的输入；当前为了辩论连贯性共享完整讨论记录。如果同模型实例开始互相附和，下一步可以加「brief 模式」（只给议题 + 上一位发言 + 角色摘要），而不是继续加实例。
